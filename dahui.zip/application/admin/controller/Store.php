<?php
namespace app\admin\controller;

use think\Controller;
use think\Db;
use think\Request;
use think\Paginator;

class Store extends Base
{
	//领票点列表
    public function index()
    {
    	/*$admininfo = getAdminInfo(session('admin_id'));
		
    	switch($admininfo['role_id']){
			case 1:
				$map = '';
			break;
			case 2:
				//店员信息
				$map['role_id'] = 5;
			break;
		}*/
    	//select 得到二维数组  find 得到一维数组
    	$count = Db::name('store')->count();
    	
		$list = Db::name('store')->paginate(21,$count);
		$page = $list->render();
		
		$this -> assign('list',$list);
		$this->assign('pager',$page);
		
    	return view();
    }
	
	//添加领票点
	public function add(){
		//是否为POST请求
		$request = Request::instance();
		
		if($request->isPost()){
			//请求参数
			$data = $request->param(); // 收集数据
			
			$res = Db::name('store')->insert($data); // 写入数据到数据库
			
			if($res){
				$msg = ['status'=>1,'msg'=>'添加领票点成功','url'=>url('admin/store/index')];
			}else{
				$msg = ['status'=>0,'msg'=>'添加领票点失败'];
			}
			return json($msg);
		}
		
		//获取城市列表
		$citylist = Db::name('city')->order('orderid asc')->select();
		$this->assign('citylist',$citylist);
		
		return view();
	}
	
	//编辑领票点
	public function edit(){
		//是否为POST请求
		$request = Request::instance();
		
		$store_id = input('store_id');
		$store = Db::name('store')->where('store_id',$store_id)->find();
		
		if($request->isPost()){
			//请求参数
			$data = $request->param(); // 收集数据
			
			$res = Db::name('store')->update($data); // 写入数据到数据库
			
			if($res){
				$msg = ['status'=>1,'msg'=>'修改领票点成功','url'=>url('admin/store/index')];
			}else{
				$msg = ['status'=>0,'msg'=>'修改领票点失败'];
			}
			return json($msg);
		}
		//获取城市列表
		$citylist = Db::name('city')->order('orderid asc')->select();
		$this->assign('citylist',$citylist);
		$this->assign('store',$store);
		
		return view();
	}
	
	//删除角色
	public function del(){
		//是否为POST请求
		$request = Request::instance();
		if($request->isPost()){
			// 删除文章
	    	$res = Db::name('store')->where('store_id',input('id'))->delete();
			
			if($res){
				$msg = ['status'=>1,'msg'=>'删除领票点成功','url'=>url('admin/store/index')];
			}else{
				$msg = ['status'=>-2,'msg'=>'删除领票点失败'];
			}
			
			return json($msg);
		}
	}
}
