<?php
namespace app\admin\controller;

use think\Controller;
use think\Db;
use think\Request;
use think\Paginator;

class User extends Base
{
	//用户列表
    public function index()
    {
    	$admininfo = getAdminInfo(session('admin_id'));
		//关键字
		$keywords = input('keywords');
		$search_name = input('search_name');
		
    	switch($admininfo['role_id']){
			case 1:
				if($keywords){
					$map['utel'] = ['like','%'.$keywords.'%'];
				}elseif($search_name){
					$map['uname'] = ['like','%'.$search_name.'%'];
				}else{
					$map = '';
				}
			break;
			case 2:
				if($keywords){
					$map['utel'] = $keywords;
				}elseif($search_name){
					$map['uname'] = $search_name;
				}else{
					$map['utel'] = 'aaa';
				}
			break;
		}
		
    	//select 得到二维数组  find 得到一维数组
    	$count = Db::name('user')->where($map)->count();
    	
		$list = Db::name('user')->where($map)->paginate(21,$count);
		$page = $list->render();
		
		$this -> assign('list',$list);
		$this->assign('pager',$page);
		
    	return view();
    }
	
	//添加会员
	public function add(){
		//是否为POST请求
		$request = Request::instance();
		
		if($request->isPost()){
			//请求参数
			$data = $request->param(); // 收集数据
			$data['addtime'] = time();
			$data['edittime'] = time();
			$data['ip'] = $request->ip();
			$password = mt_rand(100000,999999);
			$data['password'] = md5($password);
			//判断数据库中是否已存在该邀请码
			$randomstr = randomkeys(5);
			$code = Db::name('user')->where('ucode',$randomstr)->value('ucode');
			
			if($code){
				$data['ucode'] = randomkeys(5);
			}else{
				$data['ucode'] = $randomstr;
			}
			
			$res = Db::name('user')->insert($data); // 写入数据到数据库
			
			if($res){
				$msg = ['status'=>1,'msg'=>'添加会员成功','url'=>url('admin/user/index')];
			}else{
				$msg = ['status'=>0,'msg'=>'添加会员失败'];
			}
			return json($msg);
		}
		
		return view();
	}
	
	//编辑会员
	public function edit(){
		//是否为POST请求
		$request = Request::instance();
		
		$uid = input('uid');
		$user = Db::name('user')->where('uid',$uid)->find();
		
		if($request->isPost()){
			//请求参数
			$data = $request->param(); // 收集数据
			$data['edittime'] = time();
			
			if($data['is_show'] == 1){
				$data['store_id'] = session('store_id');
			}
			
			$res = Db::name('user')->update($data); // 写入数据到数据库
			
			if($res){
				$msg = ['status'=>1,'msg'=>'修改会员成功','url'=>url('admin/user/index')];
			}else{
				$msg = ['status'=>0,'msg'=>'修改会员失败'];
			}
			return json($msg);
		}
		$this->assign('user',$user);
		
		return view();
	}
	
	//删除角色
	public function del(){
		//是否为POST请求
		$request = Request::instance();
		if($request->isPost()){
			// 删除文章
	    	$res = Db::name('user')->where('uid',input('id'))->delete();
			
			if($res){
				$msg = ['status'=>1,'msg'=>'删除会员成功','url'=>url('admin/user/index')];
			}else{
				$msg = ['status'=>-2,'msg'=>'删除会员失败'];
			}
			
			return json($msg);
		}
	}
}
