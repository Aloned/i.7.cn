<?php
namespace app\home\controller;

use think\Controller;
use think\Db;
use think\Request;
use think\Session;
use think\Paginator;

class User extends BaseUser
{
	//个人中心
	public function my(){
		//获取当前用户邀请码
    	$ucode = Db::name('user')->where('uid',session('userid'))->value('ucode');
    	//我邀请的人
    	$list = Db::name('user')->where('ufrom',$ucode)->select();
		
		//查询所有人
		$all = Db::name('user')->limit(10)->select();
		foreach($all as $key=>$val){
			$mylist[$key] = ['uid'=>$val['uid'],'name'=>$val['uname'],'invite'=>inviteNumber($val['ucode']),'invited'=>invitedNumber($val['ucode'])];
		}
		
		$sortlist = sortArr($mylist,'invite',SORT_DESC,SORT_NUMERIC);
		$this->assign('sortlist',$sortlist);
		$this->assign('list',$list);
		$this->assign('nav',99);
		$this->assign('nav2',1);
		return view();
	}
	
	//个人资料
	public function person(){
		$detail = Db::name('user')->where('uid',session('userid'))->find();
		$this->assign('detail',$detail);
		
		$this->assign('nav',99);
		$this->assign('nav2',2);
		return view();
	}
	
	//修改密码
	public function edit(){
		$this->assign('nav2',3);
		$this->assign('nav',99);
		return view();
	}
}
