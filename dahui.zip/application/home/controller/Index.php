<?php
namespace app\home\controller;

use think\Controller;
use think\Db;
use think\Request;
use think\Session;
use think\Paginator;

class Index extends Base
{
	//首页
    public function index()
    {
    	//Banner
    	$banners = Db::name('banner')->where('type',1)->select();
		//参会嘉宾
		$guestList = Db::name('photo')->where('cat_id',3)->limit(8)->select();
		//合作伙伴
		$catmap = ['parent_id'=>7,'is_show'=>1];
		$cates = Db::name('category')->where($catmap)->field('cat_id,cat_name')->select();
		
		foreach($cates as $key=>$val){
			$list[$key]['name'] = $val['cat_name'];
			$list[$key]['children'] = Db::view('photo','id,cat_id,title,description,thumb,content,is_show,is_hot,is_recommend,rank,addtime')->where('cat_id',$val['cat_id'])->order('rank desc')->select();
		}

		$this->assign('banners',$banners);
		$this->assign('guestList',$guestList);
		//合作伙伴
		$this->assign('partList',$list);
		$this->assign('nav',0);
		return view();
    }
}
