<?php
namespace app\home\controller;

use think\Controller;
use think\Db;
use think\Request;
use think\Session;
use think\Paginator;
use think\Loader;
use send\WsMessageSend;

class Ajax extends Controller
{
	//发送验证码
	public function send(){
		$request = Request::instance();
		//短信验证码
		$message = Db::name('message')->where('id',1)->find();
		
		//随机生成验证码
		$code = mt_rand(1000, 9999);
		
		if($request->isPost()){
			$tel = input('param.utel/s');
		
			//电话是否已经存在
			$user = Db::name('user')->where('utel',$tel)->find();
			//插入验证码
			$content = str_replace("@",$code,$message['msg']);
			
			if(isset($user)){
				$msg = ['status'=>-1,'msg'=>'电话号码已被使用'];
			}else{
				$sendMsg = new WsMessageSend();
				$result = $sendMsg->send($message['account'], md5($message['password']), $tel, $content,'','');
				
				if($result->StatusCode == 'OK'){
					$msg = ['status'=>1,'msg'=>'发送成功'];
					session('code',$code);
				}else{
					$msg = ['status'=>0,'msg'=>'发送失败','data'=>$result];
				}
			}
			
			return json($msg);
		}
	}
	//报名下一步
    public function step()
    {
		//是否为POST请求
		$request = Request::instance();
		if($request->isPost()){
			$tel = input('param.utel/s');
			$code = input('param.code/s');
			
			if(session('code') == $code){
				$msg = ['status'=>1,'msg'=>'验证通过'];
			}else{
				$msg = ['status'=>0,'msg'=>'验证码不正确'];
			}
			
			return json($msg);
		}
    }
	//第二步
	public function apply(){
		//是否为POST请求
		$request = Request::instance();
		if($request->isPost()){
			$data = $request->param();
			$data['password'] = md5($data['password']);
			$data['addtime'] = time();
			$data['edittime'] = time();
			$data['ip'] = $request->ip();
			
			//判断数据库中是否已存在该邀请码
			$randomstr = randomkeys(5);
			$code = Db::name('user')->where('ucode',$randomstr)->value('ucode');
			
			if($code){
				$data['ucode'] = randomkeys(5);
			}else{
				$data['ucode'] = $randomstr;
			}
			
			//电话是否已经存在
			$user = Db::name('user')->where('utel',$data['utel'])->find();
			
			if(isset($user)){
				$msg = ['status'=>-1,'msg'=>'您已报过名'];
			}else{
				$res = Db::name('user')->insert($data);
				if($res){
					$msg = ['status'=>1,'msg'=>'报名成功','url'=>url('home/online/success')];
				}else{
					$msg = ['status'=>0,'msg'=>'报名失败'];
				}
			}
			
			return json($msg);
		}
	}
	
	//修改密码
	public function edit(){
		//是否为POST请求
		$request = Request::instance();
		if($request->isPost()){
			$password = input('password');
			
			$res = Db::name('user')->where('uid',session('userid'))->update(['password'=>md5($password)]);
			if($res){
				$msg = ['status'=>1,'msg'=>'密码修改成功','url'=>url('/my')];
			}else{
				$msg = ['status'=>0,'msg'=>'密码修改失败'];
			}
			
			return json($msg);
		}
	}
}
