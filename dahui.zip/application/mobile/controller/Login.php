<?php
namespace app\mobile\controller;

use think\Controller;
use think\Db;
use think\Session;
use think\Request;

class Login extends Base {
	//登录
    public function index()
    {
    	$request = Request::instance();
		
		if($request->isPost()){
			$map['utel'] = input('utel/s');
			$map['password'] = input('password/s');
			if (!empty($map['utel']) && !empty($map['password'])) {
				//md5 加密
				$map['password'] = md5($map['password']);
				
				$user = Db::name('user')->where($map)->find();
				
				if (is_array($user)) {
					session('userid', $user['uid']);
					$msg = ['status' => 1001,'msg'=>'登录成功','url' => url('/mobile/my')];
				} else {
					$msg = ['status' => 1002, 'msg' => '账号或密码不正确'];
				}
			} else {
				$msg = ['status' => 1003, 'msg' => '请填写账号密码'];
			}
			
			return json($msg);
		}
		$this->assign('nav',99);
		
		return view('user/login');
    }
	
	/**
     * 退出登陆
     */
    public function logout(){
		session::clear();
		
        $msg = ['status' => 1, 'msg' => '退出成功'];
		return json($msg);
    }
}
