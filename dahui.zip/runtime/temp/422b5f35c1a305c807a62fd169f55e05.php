<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:41:"./application/mobile/view/user\login.html";i:1528267085;s:44:"./application/mobile/view/public\header.html";i:1528187819;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta name="format-detection" content="telephone=no, email=no">
	<meta content="yes" name="apple-mobile-web-app-capable"/>
    <!-- Safari浏览器私有meta属性 -->
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-title" content="APP name">
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/mobile/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jquery-2.1.1.min.js"></script>
	<!-- <script src="__PUBLIC__/mobile/js/touch.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jsrem.js"></script>
	<script src="__PUBLIC__/mobile/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/style.css">
	<title>用户登录 - <?php echo $website['title']; ?></title>
</head>
<body>
<head>
	<div class="head">
		<ul class="wrap">
			<li class="fl"><a href="<?php echo $website['url']; ?>/mobile"><img src="<?php echo $website['logo']; ?>"></a></li>
			<li class="fr"><p class="col000 textr font22">报名已破<span class="fontber"><?php echo $joinnum; ?></span>人<br><span class="font16">每晚6点更新数据</span></p></li>
		</ul>
	</div>
</head>
				
<div class="banner-wrap clearfix"></div>

<!-- 报名 -->
<article>
	<div class="user-login">
		<h3 class="fontb textc col000">用户登录</h3>
		<div class="wrap">
			<dl class="clearfix formstyle">
			    <dt class="textr">手机</dt>
			    <dd><input type="text" name="utel" placeholder="请输入手机号码" class="input1 phoneInput"></dd>
			</dl>
			<dl class="clearfix formstyle">
			    <dt class="textr">密码</dt>
			    <dd><input type="password" name="password" placeholder="请输入您的密码"  class="input1 codeInput"></dd>
			</dl>
			<a href="javascript:;" class="user-login-btn nextstep">登录</a>
	    </div>
	</div>
</article>

<nav>
	<div class="nav-fotter clearfix">
		<ul class="clearfix">
			<li><a href="/mobile/page/1.html">介绍</a></li>
			<li><a href="/mobile/guest.html">嘉宾</a></li>
			<li><a href="/mobile/page/2.html">议程</a></li>
			<li><a href="/mobile/place.html">领票点</a></li>
			<li><a href="/mobile/news.html">动态</a></li>
			<li class="active"><a href="/mobile/my.html">我的</a></li>
		</ul>
	</div>
</nav>
<script type="text/javascript">
	var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
	var sendBtn = $('.sendbtn');
	var phoneInput = $('.phoneInput'); //手机号
	var codeInput = $('.codeInput'); //验证码
	var loginBtn = $('.user-login-btn'); //下一步

	// 判断手机号是否正确
	function isTel(phoneInput) {
		var valuePhone = phoneInput.val();
		if(valuePhone.length == 11 && myreg.test(valuePhone)) {
			return true;
		} else {
			alert("输入手机有误，请重新输入！");
			return false;
		}
	}

	// 下一步 验证  手机号 和验证码填写是否正确
	function mobileverification() {
		var tpl = $(".phoneInput").val();
		var mycode = $(".codeInput").val();
		if(!tpl) {
			alert('请输入电话号码');
			return false;
		}
		if(!mycode) {
			alert('请输入密码');
			return false;
		}
		$.ajax({
			type: "post",
			url: "<?php echo url('/mobile/login'); ?>",
			data: {
				'utel': phoneInput.val(),
				'password':	mycode
			},
			dataType: 'json',
			async: true,
			success: function(res) {
				if(res.status == 1001) {
					window.location.href = res.url;
				}else{
					alert(res.msg);
				}
			},
			error: function(e) {
				console.log(e)
			}
		});
	}


	// 下一步
	$('.nextstep').click(function() {
		mobileverification();
	});
</script>
</body>
</html>