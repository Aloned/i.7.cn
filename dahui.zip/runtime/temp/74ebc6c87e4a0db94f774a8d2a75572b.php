<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:40:"./application/home/view/index\index.html";i:1528093910;s:42:"./application/home/view/public\header.html";i:1528189644;s:42:"./application/home/view/public\footer.html";i:1528257730;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/home/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/home/js/jquery.min.js"></script>
	<!-- <script src="__PUBLIC__/home/js/touch.js"></script> -->
	<script src="__PUBLIC__/home/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/style.css">
	<script type="text/javascript">if(window.location.toString().indexOf('pref=padindex') != -1){}else{if(/AppleWebKit.*Mobile/i.test(navigator.userAgent) || (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/.test(navigator.userAgent))){if(window.location.href.indexOf("?mobile")<0){try{if(/Android|Windows Phone|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)){window.location.href="/mobile";}else if(/iPad/i.test(navigator.userAgent)){}else{}}catch(e){}}}}</script>
	<title><?php echo $website['title']; ?></title>
</head>
<body>
<head>
	<div class="head">
		<div class="wrap">
			<div class="fl logo"><a href="<?php echo $website['url']; ?>"><img src="<?php echo $website['logo']; ?>"></a></div>
			<div class="fr nav">
				<?php echo widget('widget/head'); ?>
			</div>
			<p class="col000 textr font14 head-pos">报名已破<span class="fontber"><?php echo $joinnum; ?></span>人<br><span class="font12 col7e">每晚6点更新数据</span></p>
		</div>
	</div>
</head>
				
<!-- 首页banner -->
<article>
	<div class="banner">
		<div class="wrap z-index-box">
			<img class="b-img1" src="__PUBLIC__/home/images/bicon1.png">
			<h3 class="font40 fontb col000 textc">第六届&nbsp;&nbsp;多谢杯</h3>
			<img class="b-img2" src="__PUBLIC__/home/images/bicon2.png">
			<p class="font30 fontl col000 textc">连接你我&nbsp;&nbsp;&nbsp;&nbsp;连接世界</p>
			<a href="online.html" class="button-sty font36 colfff textc">立即报名</a>
			<p class="font16 textc col000 fontl">已报名<?php echo $joinnum; ?>人</p>
			<p class="font-b font28 textc col000 fontl">7月19号<br/>郑州国际会展中心</p>
		</div>
		<img src="__PUBLIC__/home/images/bicon3.png" class="b-bgimg">
	</div>
</article>

<!-- 大会信息 -->
<article>
	<div class="meeting-info">
		<div class="wrap">
			<h3 class="fontb textl font40 colfff">大会信息</h3>
			<p class="font20 colfff">
				<span class="fontb">时间：</span>2018年7月19日<br/>
				<span class="fontb">地点：</span>郑州国际会展中心辕厅<br/>
				<span class="fontb">主题：</span>区块链、共享经济<br/>
				<span class="fontb">规模：</span>1万人<br/>
			</p>
			<p class="font20 colfff">
				<span class="fontb">招商：</span>18012345678
				<span class="fontb">投诉：</span>0371-61234567<br/>
				<span class="fontb">QQ群：</span>河南创业者群1：56465
			</p>
		</div>
	</div>
</article>

<!-- 参会嘉宾 -->
<article>
	<div class="meeting-guest bg2">
		<div class="wrap">
			<h3 class="fontb font40 textl col000">参会嘉宾</h3>
			<ul class="index">
				<?php if(is_array($guestList) || $guestList instanceof \think\Collection || $guestList instanceof \think\Paginator): $i = 0; $__LIST__ = $guestList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
					<li>
						<div class="m-g-img">
							<img src="<?php echo $vo['thumb']; ?>" />
						</div>
						<p class="font20 textc col000"><?php echo $vo['title']; ?><br><span class="font14"><?php echo $vo['subtitle']; ?></span></p>
					</li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
			</ul>
		</div>
	</div>
</article>

<!-- 合作伙伴 -->
<article>
	<div class="cooperation">
		<div class="wrap">
			<h3 class="fontb font40 textl col000">合作伙伴</h3>
			<?php if(is_array($partList) || $partList instanceof \think\Collection || $partList instanceof \think\Paginator): $i = 0; $__LIST__ = $partList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<h4 class="font22 textl col000"><?php echo $vo['name']; ?></h4>
				<ul class="clearfix">
					<?php if(is_array($vo['children']) || $vo['children'] instanceof \think\Collection || $vo['children'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['children'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$sub): $mod = ($i % 2 );++$i;?>
						<li><img src="<?php echo $sub['thumb']; ?>"/></li>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
	</div>
</article>

<!-- 往期回顾 -->
<article>
	<div class="past-period">
		<div class="wrap" id="sliderWrap">
			<h3 class="fontb textl font40 colfff">往期回顾</h3>
			<div class="p-p-img-list clearfix">
				<ul class="clearfix">
					<li><img src="__PUBLIC__/home/images/iicon1.png">
						<p class="font30 colfff textc">615位<br/><span class="font18">演讲嘉宾</span></p>
					</li>
					<li><img src="__PUBLIC__/home/images/iicon2.png">
						<p class="font30 colfff textc">20000+<br/><span class="font18">参会人员</span></p>
					</li>
					<li><img src="__PUBLIC__/home/images/iicon3.png">
						<p class="font30 colfff textc">超过2万+<br/><span class="font18">参会企业</span></p>
					</li>
					<li><img src="__PUBLIC__/home/images/iicon4.png">
						<p class="font30 colfff textc">552位<br/><span class="font18">媒体</span></p>
					</li>
					<li><img src="__PUBLIC__/home/images/iicon5.png">
						<p class="font30 colfff textc">720家<br/><span class="font18">品牌参与</span></p>
					</li>
					<li><img src="__PUBLIC__/home/images/iicon6.png">
						<p class="font30 colfff textc">120家<br/><span class="font18">新媒体</span></p>
					</li>
					<li><img src="__PUBLIC__/home/images/iicon7.png">
						<p class="font30 colfff textc">700+<br/><span class="font18">稿件发布</span></p>
					</li>
					<li><img src="__PUBLIC__/home/images/iicon8.png">
						<p class="font30 colfff textc">3000万次+<br/><span class="font18">曝光次数</span></p>
					</li>
				</ul>
			</div>
			<div class="swiper-container clearfix">
				<div class="swiper-wrapper">
					<div class="swiper-slide">
						<img src="__PUBLIC__/home/images/img1.jpg">
						<p class="textl colfff font20">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/home/images/img1.jpg">
						<p class="textl colfff font20">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/home/images/img1.jpg">
						<p class="textl colfff font20">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/home/images/img1.jpg">
						<p class="textl colfff font20">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/home/images/img1.jpg">
						<p class="textl colfff font20">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/home/images/img1.jpg">
						<p class="textl colfff font20">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/home/images/img1.jpg">
						<p class="textl colfff font20">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/home/images/img1.jpg">
						<p class="textl colfff font20">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</article>

<script type="text/javascript">
	$(document).ready(function() {

		for(var i = 0; i < $('.swiper-slide').length; i++) {
			if(i % 2 != 0) {
				$('.swiper-slide').eq(i).css('padding-left', 15)
			}
		}

		var mySwiper = new Swiper('.swiper-container', {
			direction: 'horizontal',
			loopedSlides: 8,
			loop: true,
			slidesPerView: 2,
			slidesPerGroup: 2,
			autoplay: {
				delay: 3000, //1秒切换一次
			}
		})
		//鼠标覆盖停止自动切换
		mySwiper.el.onmouseover = function() {
				mySwiper.autoplay.stop();
			},
			//鼠标移除停止自动切换
			mySwiper.el.onmouseout = function() {
				mySwiper.autoplay.start();
			}

	})
</script>

<!-- 联系我们 -->
<article>
	<div class="contact-us">
		<div class="wrap">
			<h3 class="fontb textl font40 col000">联系我们</h3>
			<ul>
				<li>
					<h4 class=" font24 col000 textl">会务合作</h4>
					<p class="font20 col000 fontl">张巧英</p>
					<p class="font20 col000 fontl">183 3716 8038</p>
					<p class="fontl font12 col000">anan@asdfsadf.com</p>
					</p>
				</li>
				<li>
					<h4 class="font24 col000 textl">领票地点/报名</h4>
					<p class="font20 col000 fontl">阿牛</p>
					<p class="font20 col000 fontl">183 3716 8038</p>
					<p class="fontl font12 col000">anan@asdfsadf.com</p>
					</p>
				</li>
				<li>
					<h4 class="font24 col000 textl">商务合作</h4>
					<p class="font20 col000 fontl">阿牛</p>
					<p class="font20 col000 fontl">183 3716 8038</p>
					<p class="fontl font12 col000">anan@asdfsadf.com</p>
					</p>
				</li>
				<li>
					<h4 class="font24 col000 textl">媒体合作</h4>
					<p class="font20 col000 fontl">阿牛</p>
					<p class="font20 col000 fontl">183 3716 8038</p>
					<p class="fontl font12 col000">anan@asdfsadf.com</p>
					</p>
				</li>
			</ul>
			<!-- text-i  -->
		</div>
	</div>
</article>
<!--尾部-->
	<footer>
		<div class="footer">
			<div class="wrap">
				<img src="__PUBLIC__/home/images/fb.png">
				<p class="textc font14 col868">©2005-2025河南创业者大会版权所有豫ICP备16026558号<br/>景安网路唯一官方指定技术支持合作商</p>
			</div>
		</div>
	</footer>
	</body>
</html>