<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:42:"./application/mobile/view/user\ticket.html";i:1528276777;s:45:"./application/mobile/view/public\nheader.html";i:1528268311;s:45:"./application/mobile/view/public\nfooter.html";i:1528267851;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta name="format-detection" content="telephone=no, email=no">
	<meta content="yes" name="apple-mobile-web-app-capable"/>
    <!-- Safari浏览器私有meta属性 -->
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-title" content="APP name">
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/mobile/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jquery-2.1.1.min.js"></script>
	<!-- <script src="__PUBLIC__/mobile/js/touch.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jsrem.js"></script>
	<script src="__PUBLIC__/mobile/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/style.css">
	<title>我的门票</title>
</head>
<body>
<head>
	<div class="head">
		 <h2 class="textc font32 fontber col000">我的门票</h2>
		 <a href="javascript:history.back()" class="font32 col000 back"><img src="__PUBLIC__/mobile/images/iconright.png" class="iconrgiht">返回</a>
	</div>
</head>
					
<!-- 我的门票 -->
<article>
	<div class="conl clearfix">
		<ul>
			<li class="font32 textc active">待领取</li>
			<li class="font32 textc">已领取</li>
		</ul>
	</div>
	<div class="conl-cont clearfix" id="conlCont0">
		<div class="myticket-cont">
			<div class="wrap">
				<?php if($flag == 0): ?>
					<p class="font22 colf0 mart50">您有一张门票待领取<br/>请在大会开始前及时前往领票地点领取纸质门票</p>
				<?php endif; ?>
				
				<a href="/mobile/place.html" class="nolead">查看领票点</a>
				<img src="__PUBLIC__/mobile/images/banner1.png" />
				<h4 class="font30 fontber">第六届中国创业者大会</h4>
				<p class="font26 col000">时间：2018年7月19日9：00入场<br/>地点：郑州市郑东新区CDB会展中心 轩辕厅</p>
			</div>
		</div>
	</div>
	<div class="conl-cont clearfix" id="conlCont1" style="display: none;">
		<div class="myticket-cont">
			<div class="wrap">
				<img src="__PUBLIC__/mobile/images/banner1.png" />
				<h4 class="font30 fontber">第六届中国创业者大会</h4>
				<p class="font26 col000">时间：2018年7月19日9：00入场<br/>地点：郑州市郑东新区CDB会展中心 轩辕厅</p>
				
				<?php if($flag == 1): ?>
					<a href="javascript:;" class="lead">已领取</a>
					<p class="font26 col000">领取地点：<?php echo $point['store_address']; ?><br/>领票时间：<?php echo date("Y-m-d H:i:s",$point['edittime']); ?></p>
				<?php endif; ?>
				
			</div>
		</div>
	</div>
</article>
<script type="text/javascript">
	// 切换
	(function() {

		function tab() {
			var conlLi = $('.conl li');

			conlLi.bind('touchstart', function() {
				var _index = $(this).index();
				$(this).addClass('active').siblings().removeClass('active');
				$('.conl-cont').hide();
				$('#conlCont' + _index).show();
			})
		}

		tab();
		
		$('.select-show').bind('touchstart', function() {
			if($(this).next().is(':hidden')) {
				$(this).children().next().next().children().attr('src', 'images/iconshow.png')
				$(this).next().show();
			} else {
				$(this).next().hide();
				$(this).children().next().next().children().attr('src', 'images/iconhide.png')
			}
		});

	})();
</script>

<nav>
	<div class="nav-fotter clearfix">
		<ul class="clearfix">
			<li><a href="/mobile/page/1.html">介绍</a></li>
			<li><a href="/mobile/guest.html">嘉宾</a></li>
			<li><a href="/mobile/page/2.html">议程</a></li>
			<li><a href="/mobile/place.html">领票点</a></li>
			<li><a href="/mobile/news.html">动态</a></li>
			<li class="active"><a href="/mobile/my.html">我的</a></li>
		</ul>
	</div>
</nav>
	</body>
</html>