<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:44:"./application/admin/view/member\editman.html";i:1528249155;}*/ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">
		<title>主页</title>

		<!--CSS-->
		<link rel="stylesheet" href="__PUBLIC__/plugins/layui/css/layui.css" />
		<link rel="stylesheet" href="__PUBLIC__/admin/css/global.css" />

		<!--JS-->
		<script type="text/javascript" src="__PUBLIC__/plugins/layui/layui.js"></script>
	</head>

	<body>
		<div class="layui-main my-admin">
			<div class="layui-tab my-tab">
				<div class="my-title-box">
					<h5 class="my-title">添加管理员</h5>
					<a href="javascript:history.go(-1);" class="layui-btn layui-btn-small layui-btn-normal"><i class="layui-icon">&#xe65c;</i></a>
				</div>
				<div class="my-content">
					<form method="post" class="layui-form" action="">
						<table class="layui-table">
							<colgroup>
								<col width="10%" />
								<col />
							</colgroup>
							<tr>
								<td align="right">用户名：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="user_name" disabled lay-verify="required" value="<?php echo $manager['user_name']; ?>" class="layui-input" placeholder="用户名" />
										</div>
										<div class="layui-form-mid layui-word-aux"><span class="txt-color3">用户名只能为字母，数字,如：xiaoma</span></div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">密码：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="password" class="layui-input" placeholder="密码" />
										</div>
										<div class="layui-form-mid layui-word-aux">密码不能为汉字</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">选择角色：</td>
								<td>
									<div class="layui-form-item">
										<?php if(is_array($rolelist) || $rolelist instanceof \think\Collection || $rolelist instanceof \think\Paginator): $i = 0; $__LIST__ = $rolelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
											<input type="radio" name="role_id" value="<?php echo $vo['role_id']; ?>" title="<?php echo $vo['role_name']; ?>" <?php if($vo['role_id'] == $manager['role_id']): ?>checked<?php endif; ?>/>
										<?php endforeach; endif; else: echo "" ;endif; ?>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">所属店铺：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<select name="store_id" id="store_id" lay-filter="store_id">
			                                    <?php if(is_array($storelist) || $storelist instanceof \think\Collection || $storelist instanceof \think\Paginator): $i = 0; $__LIST__ = $storelist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>                                            
			                                        <option value="<?php echo $vo['store_id']; ?>" <?php if($vo['store_id'] == $manager['store_id']): ?>selected<?php endif; ?> ><?php echo $vo['store_name']; ?></option>
			                                    <?php endforeach; endif; else: echo "" ;endif; ?>                                            
											</select>
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">真实姓名：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="true_name" lay-verify="required" value="<?php echo $manager['true_name']; ?>" class="layui-input" placeholder="真实姓名" />
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">联系电话：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="tel" class="layui-input" value="<?php echo $manager['tel']; ?>"  placeholder="联系电话" />
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">是否启用：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="radio" name="is_open" value="1" title="是" <?php if($manager['is_open'] == 1): ?>checked<?php endif; ?>/>
  											<input type="radio" name="is_open" value="0" title="否" <?php if($manager['is_open'] == 0): ?>checked<?php endif; ?>/>
										</div>
									</div>
								</td>
							</tr>
							<input type="hidden" name="admin_id" value="<?php echo $manager['admin_id']; ?>" />
							<tr>
								<td align="right">&nbsp;</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<button class="layui-btn" lay-submit="" data-url="<?php echo url('/admin/member/editman'); ?>" lay-filter="editman">保存</button>
											<button type="reset" class="layui-btn layui-btn-danger">重置</button>
										</div>
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
		</div>
	</body>
	<script type="text/javascript">
		layui.config({
			base: '__PUBLIC__/admin/js/modules/' //你存放新模块的目录，注意，不是layui的模块目录
		}).use('admin'); //加载入口
	</script>
</html>