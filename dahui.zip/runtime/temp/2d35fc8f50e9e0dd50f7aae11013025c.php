<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:43:"./application/mobile/view/online\index.html";i:1528189419;s:44:"./application/mobile/view/public\header.html";i:1528187819;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta name="format-detection" content="telephone=no, email=no">
	<meta content="yes" name="apple-mobile-web-app-capable"/>
    <!-- Safari浏览器私有meta属性 -->
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-title" content="APP name">
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/mobile/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jquery-2.1.1.min.js"></script>
	<!-- <script src="__PUBLIC__/mobile/js/touch.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jsrem.js"></script>
	<script src="__PUBLIC__/mobile/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/style.css">
	<title>在线报名 - <?php echo $website['title']; ?></title>
</head>
<body>
<head>
	<div class="head">
		<ul class="wrap">
			<li class="fl"><a href="<?php echo $website['url']; ?>/mobile"><img src="<?php echo $website['logo']; ?>"></a></li>
			<li class="fr"><p class="col000 textr font22">报名已破<span class="fontber"><?php echo $joinnum; ?></span>人<br><span class="font16">每晚6点更新数据</span></p></li>
		</ul>
	</div>
</head>
				
<div class="banner-wrap clearfix"></div>

<!-- 报名 -->

<article id="step1">
	<div class="user-login">
		<h3 class="fontb textc col000">在线报名</h3>
		<div class="wrap">
			<dl class="clearfix formstyle">
			    <dt class="textr">手机</dt>
			    <dd><input type="text" name="utel" placeholder="请输入您的手机号" class="input1 phoneInput"></dd>
			</dl>
			<dl class="clearfix formstyle">
			    <dt class="textr">验证码</dt>
			    <dd>
					<input type="text" name="code" placeholder="请输入您的验证码" class="input1 codeInput">
					<a href="javascript:;" class="sendbtn">发送验证码</a>
				</dd>
			</dl>
			<a href="javascript:;" class="user-login-btn nextstep">下一步</a>
	    </div>
	</div>
</article>

<!-- 报名 -->
<article id="step2" style="display: none;">
	<div class="user-login">
		<h3 class="textc fontb font36 col000">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;报 名</h3>
		<div class="wrap">
		<dl class="clearfix formstyle">
			    <dt class="textr">名字</dt>
			    <dd><input type="text" id="uname" name="uname" placeholder="请输入您的姓名" class="input1"></dd>
			</dl>
			<dl class="clearfix formstyle">
			    <dt class="textr">公司</dt>
			    <dd><input type="text" id="ucompany" name="ucompany" placeholder="请输入您的姓名" class="input1"></dd>
			</dl>
			<dl class="clearfix formstyle">
			    <dt class="textr">职务</dt>
			    <dd><input type="text" id="uposition" name="uposition" placeholder="请输入您的姓名" class="input1"></dd>
			</dl>
			<dl class="clearfix formstyle">
			    <dt class="textr">密码</dt>
			    <dd><input type="text" id="upassword" name="password" placeholder="请设置登录密码" class="input1"></dd>
			</dl>
			<a href="javascript:;" id="submit" class="user-login-btn">提交</a>
	    </div>
	</div>
</article>

<script type="text/javascript">
	var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
	var sendBtn = $('.sendbtn');
	var phoneInput = $('.phoneInput'); //手机号
	var codeInput = $('.codeInput'); //验证码
	var loginBtn = $('.user-login-btn'); //下一步

	// 判断手机号是否正确
	function isTel(phoneInput) {
		var valuePhone = phoneInput.val();
		if(valuePhone.length == 11 && myreg.test(valuePhone)) {
			return true;
		} else {
			alert("输入手机有误，请重新输入！");
			return false;
		}
	}

	// 倒计数
	function timeCount(sendBtn) {

		var wait = 59;
		var time = setInterval(function() {
			sendBtn.unbind();
			sendBtn.text(wait + '秒后');
			sendBtn.css('background', '#6f6e6e');
			sendBtn.css('cursor', 'wait');
			wait--;
			if(wait < 0) {
				clearInterval(time);
				sendBtn.text('重新发送');
				sendBtn.css('background', '#ff0000');
				sendBtn.css('cursor', 'pointer');
				sendBtn.click(function() {
					timeCount(sendBtn)
				})
			}
		}, 1000)
	}

	// 下一步 验证  手机号 和验证码填写是否正确
	function mobileverification() {
		var tpl = $(".phoneInput").val();
		var mycode = $(".codeInput").val();
		var code = $("#code").val();
		if(!tpl) {
			alert('请输入电话号码');
			return false;
		}
		if(!mycode) {
			alert('请输入验证码');
			return false;
		}
		$.ajax({
			type: "post",
			url: "<?php echo url('ajax/step'); ?>",
			data: {
				'utel': phoneInput.val(),
				'code':	mycode
			},
			dataType: 'json',
			async: true,
			success: function(res) {
				if(res.status == 1) {
					//window.location.href = res.url;
					//console.log(res);
					alert(res.msg);
					$('#step1').hide();
					$('#step2').show();
				}
				if(res.status == 0) {
					alert(res.msg);
					$('#step2').hide();
					$('#step1').show();
				}
			},
			error: function(e) {
				console.log(e)
			}
		});
	}

	// 发送验证码
	sendBtn.click(function() {
		// 判断手机号是否正确
		var phoneStuta = isTel(phoneInput);
		if(phoneStuta) {
			$.ajax({
				type: "post",
				url: "<?php echo url('ajax/send'); ?>",
				data: {
					'utel': phoneInput.val()
				},
				dataType: 'json',
				async: true,
				success: function(res) {

					if(res.status == 1) {
						// 执行倒计数
						timeCount(sendBtn)
					}
					if(res.status == 0) {
						alert('验证码发送失败，请重新发送');
					}

				},
				error: function(e) {
					console.log(e)
				}
			});
		}
	});

	// 下一步
	$('.nextstep').click(function() {
		mobileverification();
	});
	
	//第二步
	$('#submit').click(function(){
		$.ajax({
			type: "post",
			url: "<?php echo url('ajax/apply'); ?>",
			data: {
				'utel':phoneInput.val(),
				'uname': $('#uname').val(),
				'ucompany': $('#ucompany').val(),
				'uposition': $('#uposition').val(),
				'password': $('#upassword').val()
			},
			dataType: 'json',
			async: true,
			success: function(res) {
				if(res.status == 1) {
					alert(res.msg);
					console.log(res);
				}
				if(res.status == 0) {
					alert(res.msg);
				}

			},
			error: function(e) {
				console.log(e)
			}
		});
	});
</script>
</body>
</html>