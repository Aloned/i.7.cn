<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:40:"./application/admin/view/user\index.html";i:1527590217;}*/ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">
		<title>主页</title>

		<!--CSS-->
		<link rel="stylesheet" href="__PUBLIC__/plugins/layui/css/layui.css" />
		<link rel="stylesheet" href="__PUBLIC__/admin/css/global.css" />

		<!--JS-->
		<script type="text/javascript" src="__PUBLIC__/plugins/layui/layui.js"></script>
	</head>

	<body>
		<div class="layui-main my-admin">
			<div class="layui-tab my-tab">
				<div class="my-title-box">
					<h5 class="my-title">会员列表</h5>
					<?php if(session('role_id') == 1): ?>
						<a href="<?php echo url('/admin/user/add'); ?>" class="layui-btn layui-btn-small layui-btn-normal"><i class="layui-icon">&#xe654;</i>  添加</a>
					<?php endif; ?>
				</div>
				<div class="my-title-box" style="margin-top: 15px;">
					<form class="layui-form" action="<?php echo url('admin/user/index'); ?>" id="search" method="post">
						<div class="layui-form-item">
							<!--<div class="layui-input-inline">
								<input type="text" name="search_name" placeholder="姓名" class="layui-input">
							</div>-->
							<div class="layui-input-inline  my-input-line">
								<input type="text" name="keywords" placeholder="电话号码" class="layui-input">
							</div>
							<button type="submit" class="layui-btn layui-btn-danger"><i class="layui-icon">&#xe615;</i></button>
						</div>
					</form>
				</div>
				<div class="my-content">
					<table class="layui-table">
						<thead>
							<tr>
			                   	<th>ID</th>
			                   	<th>姓名</th>
			                   	<th>电话</th>
			                   	<th>公司</th>
			                   	<th>职位</th>
			                   	<th>邀请人数</th>
			                   	<th>是否领票</th>
			                   	<th>报名时间</th>
			                   	<th>操作</th>
			               	</tr>
						</thead>
						<tbody>
							<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $k=>$vo): ?>
					  			<tr>
					  			 	<td><?php echo $vo['uid']; ?></td>
			                     	<td><?php echo $vo['uname']; ?></td>
					     		 	<td><?php echo $vo['utel']; ?></td>
					     		 	<td><?php echo $vo['ucompany']; ?></td>
					     		 	<td><?php echo $vo['uposition']; ?></td>
					     		 	<th><span class="txt-color2"><?php echo inviteNumber($vo['ucode']); ?></span></th>
			                 		<td>
		                             	<?php if(($vo['is_show']) == '1'): ?><span class="my-status-bg layui-bg-green"><i class="layui-icon">&#xe605;</i></span><?php else: ?><span class="my-status-bg layui-bg-red"><i class="layui-icon">&#x1006;</i></span><?php endif; ?>                            
		                         	</td>
			                     	<td><?php echo date('Y-m-d H:i:s',$vo['addtime']); ?></td>
			                     	<td>
			                      		<a class="layui-btn layui-btn-small" href="<?php echo url('/admin/user/edit',['uid'=>$vo['uid']]); ?>"><i class="layui-icon">&#xe642;</i></a>
			                      		<a class="layui-btn layui-btn-danger layui-btn-small del" href="javascript:;" data-url="<?php echo url('/admin/user/del'); ?>" data-id="<?php echo $vo['uid']; ?>"><i class="layui-icon">&#xe640;</i></a>
					     			</td>
			                   	</tr>
			                <?php endforeach; endif; else: echo "" ;endif; ?>
						</tbody>
					</table>
					<div class="my-pager">
						<?php echo $pager; ?>
					</div>
				</div>
			</div>
		</div>
	</body>
	<script type="text/javascript">
		layui.config({
			base: '__PUBLIC__/admin/js/modules/' //你存放新模块的目录，注意，不是layui的模块目录
		}).use('user'); //加载入口
	</script>
</html>