<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:38:"./application/home/view/user\edit.html";i:1528265696;s:42:"./application/home/view/public\header.html";i:1528189644;s:41:"./application/home/view/public\uside.html";i:1528264800;s:42:"./application/home/view/public\footer.html";i:1528257730;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/home/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/home/js/jquery.min.js"></script>
	<!-- <script src="__PUBLIC__/home/js/touch.js"></script> -->
	<script src="__PUBLIC__/home/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/style.css">
	<script type="text/javascript">if(window.location.toString().indexOf('pref=padindex') != -1){}else{if(/AppleWebKit.*Mobile/i.test(navigator.userAgent) || (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/.test(navigator.userAgent))){if(window.location.href.indexOf("?mobile")<0){try{if(/Android|Windows Phone|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)){window.location.href="/mobile";}else if(/iPad/i.test(navigator.userAgent)){}else{}}catch(e){}}}}</script>
	<title>修改密码 - <?php echo $website['title']; ?></title>
</head>
<body>
<head>
	<div class="head">
		<div class="wrap">
			<div class="fl logo"><a href="<?php echo $website['url']; ?>"><img src="<?php echo $website['logo']; ?>"></a></div>
			<div class="fr nav">
				<?php echo widget('widget/head'); ?>
			</div>
			<p class="col000 textr font14 head-pos">报名已破<span class="fontber"><?php echo $joinnum; ?></span>人<br><span class="font12 col7e">每晚6点更新数据</span></p>
		</div>
	</div>
</head>
				
<div class="banner-wrap clearfix"></div>
<!-- 个人中心 -->
<div class="wrap clearfix">
	<div class="box-left fl">
		<ul class="side-nav">
	<li><a href="/my.html" <?php if($nav2 == '1'): ?>class="active"<?php endif; ?> >我的门票</a></li>
	<li><a href="/person.html" <?php if($nav2 == '2'): ?>class="active"<?php endif; ?> >个人资料</a></li>
	<li><a href="/my.html" <?php if($nav2 == '3'): ?>class="active"<?php endif; ?> >我的邀请</a></li>
	<li><a href="javascript:;" class="logout">退出</a></li>
</ul>

<script type="text/javascript">
	$(function(){
		$('.logout').click(function(){
			$.ajax({
				type: "post",
				url: "<?php echo url('login/logout'); ?>",
				data: {},
				dataType: 'json',
				async: true,
				success: function(res) {
					if(res.status == 1) {
						alert(res.msg);
						window.location.href = '/';
					}
				},
				error: function(e) {
					console.log(e)
				}
			});
		});
	});
</script>

	</div>
	<div class="box-right fr">
	    <div class="modifdata-list">
    	    <h3 class="textc fontb font36 col000">修改密码</h3>
			<dl class="clearfix formstyle">
			    <dt>新密码</dt>
			    <dd><input type="password" id="password" name="password" placeholder="请输入密码" class="input1"></dd>
			</dl>
			<dl class="clearfix formstyle">
				<dt>&nbsp;</dt>
				<dd><a href="javascript:;" id="edit" class="user-login-btn">确定</a></dd>
			</dl>
		</div>
    </div>
</div>
<script type="text/javascript">
	$(function(){
		$('#edit').click(function(){
			$.ajax({
				type: "post",
				url: "<?php echo url('ajax/edit'); ?>",
				data: {
					'password':$('#password').val()
				},
				dataType: 'json',
				async: true,
				success: function(res) {
					if(res.status == 1) {
						alert(res.msg);
						window.location.href = res.url;
					}
				},
				error: function(e) {
					console.log(e)
				}
			});
		});
	});
</script>
<!--尾部-->
	<footer>
		<div class="footer">
			<div class="wrap">
				<img src="__PUBLIC__/home/images/fb.png">
				<p class="textc font14 col868">©2005-2025河南创业者大会版权所有豫ICP备16026558号<br/>景安网路唯一官方指定技术支持合作商</p>
			</div>
		</div>
	</footer>
	</body>
</html>