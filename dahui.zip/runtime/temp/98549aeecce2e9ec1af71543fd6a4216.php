<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:42:"./application/admin/view/member\index.html";i:1528249677;}*/ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">
		<title>主页</title>

		<!--CSS-->
		<link rel="stylesheet" href="__PUBLIC__/plugins/layui/css/layui.css" />
		<link rel="stylesheet" href="__PUBLIC__/admin/css/global.css" />

		<!--JS-->
		<script type="text/javascript" src="__PUBLIC__/plugins/layui/layui.js"></script>
	</head>

	<body>
		<div class="layui-main my-admin">
			<div class="layui-tab my-tab">
				<div class="my-title-box">
					<h5 class="my-title">管理员列表</h5>
					<?php if(session('role_id') == 1|2): ?>
						<a href="<?php echo url('/admin/member/addman'); ?>" class="layui-btn layui-btn-small layui-btn-normal"><i class="layui-icon">&#xe654;</i>  添加</a>
					<?php endif; ?>
				</div>
				<div class="my-content">
					<table class="layui-table">
						<thead>
							<tr>
			                   	<th>ID</th>
			                   	<th>用户名</th>
			                   	<th>姓名</th>
			                   	<th>联系方式</th>
			                   	<th>所属角色</th>
			                   	<th>所属领票点</th>
			                   	<th>操作</th>
			               	</tr>
						</thead>
						<tbody>
							<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): if( count($list)==0 ) : echo "" ;else: foreach($list as $k=>$vo): ?>
					  			<tr>
					  			 	<td><?php echo $vo['admin_id']; ?></td>
					     		 	<td><?php echo $vo['user_name']; ?></td>
					     		 	<td><?php echo $vo['true_name']; ?></td>
					     		 	<td><?php echo $vo['tel']; ?></td>
					     		 	<td>
					     		 		<?php switch($vo['role_id']): case "1": ?><span class="txt-color1"><?php echo $vo['role_name']; ?></span><?php break; case "2": ?><span class="txt-color2"><?php echo $vo['role_name']; ?></span><?php break; case "3": ?><span class="txt-color3"><?php echo $vo['role_name']; ?></span><?php break; case "4": ?><span class="txt-color4"><?php echo $vo['role_name']; ?></span><?php break; default: ?><span class="txt-color1"><?php echo $vo['role_name']; ?></span></case>
					     		 		<?php endswitch; ?>
					     		 	</td>
					     		 	<td><?php echo $vo['store_name']; ?></td>
			                     	<td>
			                      		<a class="layui-btn layui-btn-small" href="<?php echo url('/admin/member/editman',['admin_id'=>$vo['admin_id']]); ?>"><i class="layui-icon">&#xe642;</i></a>
			                      		<?php if($vo['role_id'] != 1): ?>
			                      			<a class="layui-btn layui-btn-danger layui-btn-small del" href="javascript:;" data-url="<?php echo url('/admin/member/delman'); ?>" data-id="<?php echo $vo['admin_id']; ?>"><i class="layui-icon">&#xe640;</i></a>
					     				<?php endif; ?>
			                     	</td>
			                   	</tr>
			                <?php endforeach; endif; else: echo "" ;endif; ?>
						</tbody>
					</table>
				</div>
			</div>
		</div>
	</body>
	<script type="text/javascript">
		layui.config({
			base: '__PUBLIC__/admin/js/modules/' //你存放新模块的目录，注意，不是layui的模块目录
		}).use('admin'); //加载入口
	</script>
</html>