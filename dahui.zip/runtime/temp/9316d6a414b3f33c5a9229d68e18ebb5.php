<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:41:"./application/mobile/view/user\share.html";i:1528283565;s:45:"./application/mobile/view/public\nheader.html";i:1528268311;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta name="format-detection" content="telephone=no, email=no">
	<meta content="yes" name="apple-mobile-web-app-capable"/>
    <!-- Safari浏览器私有meta属性 -->
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-title" content="APP name">
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/mobile/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jquery-2.1.1.min.js"></script>
	<!-- <script src="__PUBLIC__/mobile/js/touch.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jsrem.js"></script>
	<script src="__PUBLIC__/mobile/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/style.css">
	<title>邀请函</title>
</head>
<body>
<head>
	<div class="head">
		 <h2 class="textc font32 fontber col000">邀请函</h2>
		 <a href="javascript:history.back()" class="font32 col000 back"><img src="__PUBLIC__/mobile/images/iconright.png" class="iconrgiht">返回</a>
	</div>
</head>
				
<div class="banner-wrap clearfix"></div>


<!-- 生成邀请函 -->
<article>
	<div class="wrap generate-box">
		<div class="generate-cont">
			<img src="<?php echo $img; ?>" width="100%" />
		</div>
		<a href="javascript:;">保存图片</a>
	</div>
</article>
</body>
</html>
	
	
