<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:42:"./application/mobile/view/user\invite.html";i:1528276867;s:45:"./application/mobile/view/public\nheader.html";i:1528268311;s:45:"./application/mobile/view/public\nfooter.html";i:1528267851;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta name="format-detection" content="telephone=no, email=no">
	<meta content="yes" name="apple-mobile-web-app-capable"/>
    <!-- Safari浏览器私有meta属性 -->
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-title" content="APP name">
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/mobile/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jquery-2.1.1.min.js"></script>
	<!-- <script src="__PUBLIC__/mobile/js/touch.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jsrem.js"></script>
	<script src="__PUBLIC__/mobile/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/style.css">
	<title>我的邀请</title>
</head>
<body>
<head>
	<div class="head">
		 <h2 class="textc font32 fontber col000">我的邀请</h2>
		 <a href="javascript:history.back()" class="font32 col000 back"><img src="__PUBLIC__/mobile/images/iconright.png" class="iconrgiht">返回</a>
	</div>
</head>
				
<!-- 我的邀请 -->
<article>
	<div class="conl clearfix">
		<ul>
			<li class="font32 textc active">我的邀请</li>
			<li class="font32 textc">邀请排行</li>
		</ul>
	</div>
	<div class="conl-cont clearfix" id="conlCont0">
		<div class="myinvitation-cont">
			<div class="wrap">
				<h4 class="col000 textc font40">已邀请<?php echo inviteNumber($user['ucode']); ?>人</h4>
				<p class="col000 textc font22">邀请满10人,可升级门票为VIP门票<br/>距升级VIP票还差<?php echo poorNumber($user['ucode']); ?>人</p>
				<ul>
					<li><a href="generate.html">生成邀请函</a></li>
					<li><a href="javascript:;" class="yqhyBtn">邀请好友</a></li>
				</ul>
			</div>	
		</div>
		<div class="myinvitation-list">
			<h3 class="textc font40 col000">我的邀请人</h3>
			<ul class="wrap">
				<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "您还没有邀请哦" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
					<li><span class="fl col000 font22"><?php echo $vo['uname']; ?></span><span class="fr font18"><?php echo date("Y-m-d H:i:s",$vo['addtime']); ?></span></li>
				<?php endforeach; endif; else: echo "您还没有邀请哦" ;endif; ?>
			</ul>
		</div>
	</div>
	<div class="conl-cont clearfix" id="conlCont1" style="display: none;">
		<div class="myinvitation-cont">
			<div class="wrap">
				<h4 class="col000 textc font40">当前排名第<?php echo $rank; ?>位</h4>
				<p class="col000 textc font22">截止7月18日中午12:00,邀请满10名好友领票可升级为大会VIP,领取VIP票,邀请报名数及邀请领票数前100名将分别获得大会提供的"逐梦礼包"和"奋斗大礼包"</p>
				<ul>
					<li><a href="generate.html">生成邀请函</a></li>
					<li><a href="javascript:;" class="yqhyBtn">邀请好友</a></li>
				</ul>
			</div>	
		</div>
		<div class="myinvitation-list">
			<h3 class="textc font40 col000">邀请排行榜</h3>
			<div class="wrap">
				<table class="myinvitation-table">
					<thead>
						<td>排名</td>
						<td>用户</td>
						<td>邀请人数</td>
					</thead>
					<?php if(is_array($sortlist) || $sortlist instanceof \think\Collection || $sortlist instanceof \think\Paginator): $i = 0; $__LIST__ = $sortlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<tr <?php if($user['uid'] == $vo['uid']): ?>class="active" <?php endif; ?> >
							<td><?php echo $i; ?></td>
							<td><?php echo $vo['name']; ?></td>
							<td><?php echo $vo['invite']; ?></td>
						</tr>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</table>
			</div>
		</div>
	</div>
</article>



<!-- 提示框 -->
<div class="prompt-box">
	<div class="prompt-cont">
		 <h3>邀请好友</h3>
		 <p>复制链接发给好友，让大家知道这个热血澎湃，充满希望的集会</p>
		 <p class="textc" id="content"><?php echo $website['url']; ?>/mobile/online.html?ufrom=<?php echo $user['ucode']; ?></p>
		 <a href="javascript:;" id="copyBT" data-clipboard-text="<?php echo $website['url']; ?>/mobile/online.html?ufrom=<?php echo $user['ucode']; ?>"><span>复制链接</span></a>
		 <p class="textc fontb font32">赢VIP门票，创业大会大礼包</p>
	</div>
</div>



<script type="text/javascript">
	$('.yqhyBtn').bind('touchstart',function(){
		$('.prompt-box').show();
	});
	$('.prompt-box').bind('touchstart',function(){
		$('.prompt-box').hide();
	});
	$('.prompt-cont').bind('touchstart',function(event){
		event.stopPropagation();
	});
	$('.prompt-cont a').bind('touchstart',function(event){
		
	});

      function copyArticle(event) {
        const range = document.createRange();
        range.selectNode(document.getElementById('content'));
 
        const selection = window.getSelection();
        if(selection.rangeCount > 0) selection.removeAllRanges();
        selection.addRange(range);
        document.execCommand('copy');
        alert("复制成功！");
      }
 
      document.getElementById('copyBT').addEventListener('click', copyArticle, false);
</script>


<script type="text/javascript">
	$(function(){
		function tab() {
			var conlLi = $('.conl li');

			conlLi.bind('touchstart', function() {
				var _index = $(this).index();
				$(this).addClass('active').siblings().removeClass('active');
				$('.conl-cont').hide();
				$('#conlCont' + _index).show();
			})
		}

		tab();
		
		$('.select-show').bind('touchstart',function(){
	        if ($(this).next().is(':hidden')) {
	         	$(this).children().next().next().children().attr('src','images/iconshow.png')
	         	$(this).next().show();
	        }else{
	         	$(this).next().hide();
	         	$(this).children().next().next().children().attr('src','images/iconhide.png')
	        }
		});
	});
</script>

<nav>
	<div class="nav-fotter clearfix">
		<ul class="clearfix">
			<li><a href="/mobile/page/1.html">介绍</a></li>
			<li><a href="/mobile/guest.html">嘉宾</a></li>
			<li><a href="/mobile/page/2.html">议程</a></li>
			<li><a href="/mobile/place.html">领票点</a></li>
			<li><a href="/mobile/news.html">动态</a></li>
			<li class="active"><a href="/mobile/my.html">我的</a></li>
		</ul>
	</div>
</nav>
	</body>
</html>