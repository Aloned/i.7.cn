<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:45:"./application/admin/view/member\editrole.html";i:1527474353;}*/ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">
		<title>主页</title>

		<!--CSS-->
		<link rel="stylesheet" href="__PUBLIC__/plugins/layui/css/layui.css" />
		<link rel="stylesheet" href="__PUBLIC__/admin/css/global.css" />

		<!--JS-->
		<script type="text/javascript" src="__PUBLIC__/plugins/layui/layui.js"></script>
	</head>

	<body>
		<div class="layui-main my-admin">
			<div class="layui-tab my-tab">
				<div class="my-title-box">
					<h5 class="my-title">编辑角色</h5>
					<a href="javascript:history.go(-1);" class="layui-btn layui-btn-small layui-btn-normal"><i class="layui-icon">&#xe65c;</i></a>
				</div>
				<div class="my-content">
					<form method="post" class="layui-form" action="">
						<table class="layui-table">
							<colgroup>
								<col width="10%" />
								<col />
							</colgroup>
							<tr>
								<td align="right">角色名称：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="role_name" value="<?php echo $role['role_name']; ?>" lay-verify="required" class="layui-input" placeholder="角色名称" />
										</div>
										<div class="layui-form-mid layui-word-aux">给角色起个名字吧</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">角色描述：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<textarea name="role_desc" class="layui-textarea" placeholder="角色描述"><?php echo $role['role_desc']; ?></textarea>
										</div>
										<div class="layui-form-mid layui-word-aux">角色描述</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">权限分配：</td>
								<td>
									<table class="layui-table" lay-size="lg">
										<?php if(is_array($menulist) || $menulist instanceof \think\Collection || $menulist instanceof \think\Paginator): $i = 0; $__LIST__ = $menulist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
											<tr>
												<td width="20%"><input type="checkbox" <?php if($vo['id'] == $vo['rid']): ?>checked<?php endif; ?> name="act_list[<?php echo $vo['id']; ?>]" lay-skin="primary" value="<?php echo $vo['id']; ?>" title="<?php echo $vo['title']; ?>"></td>
												<td width="80%">
													<?php if(is_array($vo['children']) || $vo['children'] instanceof \think\Collection || $vo['children'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['children'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$sub): $mod = ($i % 2 );++$i;?>
														<input type="checkbox" name="act_list[<?php echo $sub['id']; ?>]" <?php if($sub['id'] == $sub['rid']): ?>checked<?php endif; ?> lay-skin="primary" value="<?php echo $sub['id']; ?>" title="<?php echo $sub['title']; ?>">
													<?php endforeach; endif; else: echo "" ;endif; ?>
												</td>
											</tr>
										<?php endforeach; endif; else: echo "" ;endif; ?>
									</table>
								</td>
							</tr>
							<tr>
								<td align="right">&nbsp;</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<button class="layui-btn" lay-submit="" data-url="<?php echo url('/admin/member/editrole',['role_id'=>$role['role_id']]); ?>" lay-filter="editrole">保存</button>
											<button type="reset" class="layui-btn layui-btn-danger">重置</button>
										</div>
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
		</div>
	</body>
	<script type="text/javascript">
		layui.config({
			base: '__PUBLIC__/admin/js/modules/' //你存放新模块的目录，注意，不是layui的模块目录
		}).use('member'); //加载入口
	</script>
</html>