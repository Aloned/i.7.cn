<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:43:"./application/admin/view/login\editpwd.html";i:1514532645;}*/ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">
		<title>主页</title>

		<!--CSS-->
		<link rel="stylesheet" href="__PUBLIC__/plugins/layui/css/layui.css" />
		<link rel="stylesheet" href="__PUBLIC__/admin/css/global.css" />

		<!--JS-->
		<script type="text/javascript" src="__PUBLIC__/plugins/layui/layui.js"></script>
	</head>

	<body>
		<div class="layui-main my-admin">
			<div class="layui-tab my-tab">
				<div class="my-content">
					<form method="post" class="layui-form" action="">
						<table class="layui-table">
							<colgroup>
								<col width="20%" />
								<col />
							</colgroup>
							<tr>
								<td align="right">用户名：</td>
								<td><div class="layui-form-item"><?php echo $info['user_name']; ?></div></td>
							</tr>
							<tr>
								<td align="right">旧密码：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-block" style="margin-left: 0;">
											<input type="password" name="old_pw" class="layui-input" value="<?php echo $info['password']; ?>" placeholder="旧密码" />
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">新密码：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-block" style="margin-left: 0;">
											<input type="password" name="new_pw" lay-verify="required" value="" class="layui-input" placeholder="请输入新密码" />
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">确认密码：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-block" style="margin-left: 0;">
											<input type="password" name="new_pw2" lay-verify="required" value="" class="layui-input" placeholder="请输入新密码" />
										</div>
									</div>
								</td>
							</tr>
							<input type="hidden" name="admin_id" value="<?php echo $info['admin_id']; ?>"/>
							<tr>
								<td align="right">&nbsp;</td>
								<td align="center">
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<button class="layui-btn" lay-submit="" data-url="<?php echo url('/admin/login/editpwd'); ?>" lay-filter="editpwd">保存</button>
											<button type="reset" class="layui-btn layui-btn-danger">重置</button>
										</div>
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
		</div>
	</body>
	<script type="text/javascript">
		
		layui.use(['element','form'],function(){
			var element = layui.element,
				$ = layui.jquery,
				form = layui.form;
			
			form.on('submit(editpwd)',function(data){
				var url = $(this).data('url');
				
				$.ajax({
					type: "post",
					url: url,
					data: data.field,
					dataType: 'json',
					success: function(res) {
						if(res.status == 1) {
							layer.msg(res.msg, {icon: 1,time:2000},function(){
								parent.location.href = res.url;
							});
						} else {
							layer.msg(res.msg, {
								icon: 2
							});
						}
					},
					error: function(XMLHttpRequest, textStatus, errorThrown) {
						layer.msg('网络失败，请重试!', {
							icon: 2
						});
					}
				});
				
				return false;
			});
		});
	</script>
</html>