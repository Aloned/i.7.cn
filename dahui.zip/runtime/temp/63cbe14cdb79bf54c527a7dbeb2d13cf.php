<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:40:"./application/home/view/news\detail.html";i:1528095581;s:42:"./application/home/view/public\header.html";i:1528080975;s:42:"./application/home/view/public\footer.html";i:1528092995;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $detail['keywords']; ?>" />
	<meta name="description" content="<?php echo $detail['description']; ?>" />
	<!-- <script src="__PUBLIC__/home/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/home/js/jquery-2.1.1.min.js"></script>
	<!-- <script src="__PUBLIC__/home/js/touch.js"></script> -->
	<script src="__PUBLIC__/home/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/style.css">
	<title><?php echo $detail['title']; ?> - <?php echo $website['title']; ?></title>
</head>
<body>
<head>
	<div class="head">
		<div class="wrap">
			<div class="fl logo"><a href="<?php echo $website['url']; ?>"><img src="<?php echo $website['logo']; ?>"></a></div>
			<div class="fr nav">
				<!--<ul class="clearfix">
					<li><a href="#">首页</a></li>
					<li><a href="#">关于</a></li>
					<li><a href="#">议程</a></li>
					<li><a href="#">嘉宾</a></li>
					<li><a href="#">投资机构</a></li>
					<li><a href="#">动态</a></li>
					<li><a href="#">领票点</a></li>
					<li><a href="#">我的</a></li>
				</ul>-->
				<?php echo widget('widget/head'); ?>
			</div>
			<p class="col000 textr font14 head-pos">报名已破<span class="fontber"><?php echo $joinnum; ?></span>人<br><span class="font12 col7e">每晚6点更新数据</span></p>
		</div>
	</div>
</head>
				
	<!-- 动态 -->
	<article>
		<div class="dynamicinfo">
		  <div class="wrap">
				<h3 class="textc col000 font28 fontb"><?php echo $detail['title']; ?></h3>
				<p class="clearfix textc"><span class="font14"><?php echo $detail['author']; ?></span>&nbsp;&nbsp;&nbsp;&nbsp;<span class="font12 col7e"><?php echo date("Y-m-d",$detail['addtime']); ?></span></p>  
				<div class="show">
					<?php echo $detail['content']; ?>
				</div>
			</div>
		</div>
	</article>
		
<!--尾部-->
	<footer>
		<div class="footer">
			<div class="wrap">
				<img src="__PUBLIC__/home/images/fb.png">
				<p class="textc font14 col868">©2005-2025河南创业者大会版权所有豫ICP备16026558号<br/>景安网路唯一官方指定技术支持合作商</p>
			</div>
		</div>
	</footer>
	</body>
</html>