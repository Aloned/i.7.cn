<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:40:"./application/mobile/view/user\edit.html";i:1528274190;s:45:"./application/mobile/view/public\nheader.html";i:1528268311;s:45:"./application/mobile/view/public\nfooter.html";i:1528267851;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta name="format-detection" content="telephone=no, email=no">
	<meta content="yes" name="apple-mobile-web-app-capable"/>
    <!-- Safari浏览器私有meta属性 -->
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-title" content="APP name">
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/mobile/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jquery-2.1.1.min.js"></script>
	<!-- <script src="__PUBLIC__/mobile/js/touch.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jsrem.js"></script>
	<script src="__PUBLIC__/mobile/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/style.css">
	<title>修改密码</title>
</head>
<body>
<head>
	<div class="head">
		 <h2 class="textc font32 fontber col000">修改密码</h2>
		 <a href="javascript:history.back()" class="font32 col000 back"><img src="__PUBLIC__/mobile/images/iconright.png" class="iconrgiht">返回</a>
	</div>
</head>
				
<div class="banner-wrap clearfix"></div>
<!-- 报名 -->
<article>
	<div class="user-login">
		<h3 class="fontb textc col000">修改密码</h3>
		<div class="wrap">
			<dl class="clearfix formstyle">
			    <dt class="textr">新密码</dt>
			    <dd><input type="password" id="password" name="password" placeholder="请输入密码" class="input1"></dd>
			</dl>
			<a href="javascript:;" id="edit"  class="user-login-btn">确定</a>
	    </div>
	</div>
</article>
<script type="text/javascript">
	$(function(){
		$('#edit').click(function(){
			var pwd = $('#password').val();
			if(pwd == ''){
				alert('新密码不能为空');
				return false;
			}
			$.ajax({
				type: "post",
				url: "<?php echo url('ajax/edit'); ?>",
				data: {
					'password':pwd
				},
				dataType: 'json',
				async: true,
				success: function(res) {
					if(res.status == 1) {
						alert(res.msg);
						window.location.href = res.url;
					}
				},
				error: function(e) {
					console.log(e)
				}
			});
		});
	});
</script>
<nav>
	<div class="nav-fotter clearfix">
		<ul class="clearfix">
			<li><a href="/mobile/page/1.html">介绍</a></li>
			<li><a href="/mobile/guest.html">嘉宾</a></li>
			<li><a href="/mobile/page/2.html">议程</a></li>
			<li><a href="/mobile/place.html">领票点</a></li>
			<li><a href="/mobile/news.html">动态</a></li>
			<li class="active"><a href="/mobile/my.html">我的</a></li>
		</ul>
	</div>
</nav>
	</body>
</html>