<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:40:"./application/home/view/guest\index.html";i:1528097194;s:42:"./application/home/view/public\header.html";i:1528170973;s:42:"./application/home/view/public\footer.html";i:1528092995;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $seo['keywords']; ?>" />
	<meta name="description" content="<?php echo $seo['cat_desc']; ?>" />
	<!-- <script src="__PUBLIC__/home/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/home/js/jquery.min.js"></script>
	<!-- <script src="__PUBLIC__/home/js/touch.js"></script> -->
	<script src="__PUBLIC__/home/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/style.css">
	<title><?php echo $seo['cat_name']; ?> - <?php echo $website['title']; ?></title>
</head>
<body>
<head>
	<div class="head">
		<div class="wrap">
			<div class="fl logo"><a href="<?php echo $website['url']; ?>"><img src="<?php echo $website['logo']; ?>"></a></div>
			<div class="fr nav">
				<?php echo widget('widget/head'); ?>
			</div>
			<p class="col000 textr font14 head-pos">报名已破<span class="fontber"><?php echo $joinnum; ?></span>人<br><span class="font12 col7e">每晚6点更新数据</span></p>
		</div>
	</div>
</head>
				
	<div class="banner-wrap clearfix"></div>
		
	<!-- 参会嘉宾 -->
	<article>
		<div class="meeting-guest bg2">
			 <div class="wrap">
			 	 <h3 class="fontb textc font40 col000">参会嘉宾</h3>
			 	 <ul class="paging">
			 	 	<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
			 	 		<li>
				 	 		<div class="m-g-img">
				 	 			<img src="<?php echo $vo['thumb']; ?>"/>
				 	 		</div>
				 	 		<p class="font20 textc col000"><?php echo $vo['title']; ?><br><span class="font14"><?php echo $vo['subtitle']; ?></span></p>
				 	 	</li>
			 	 	<?php endforeach; endif; else: echo "" ;endif; ?>
			 	 </ul>
			 </div>
		</div>
	</article>
<!--尾部-->
	<footer>
		<div class="footer">
			<div class="wrap">
				<img src="__PUBLIC__/home/images/fb.png">
				<p class="textc font14 col868">©2005-2025河南创业者大会版权所有豫ICP备16026558号<br/>景安网路唯一官方指定技术支持合作商</p>
			</div>
		</div>
	</footer>
	</body>
</html>