<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:44:"./application/admin/view/system\editmsg.html";i:1527565513;}*/ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">
		<title>主页</title>

		<!--CSS-->
		<link rel="stylesheet" href="__PUBLIC__/plugins/layui/css/layui.css" />
		<link rel="stylesheet" href="__PUBLIC__/admin/css/global.css" />

		<!--JS-->
		<script type="text/javascript" src="__PUBLIC__/plugins/layui/layui.js"></script>
	</head>

	<body>
		<div class="layui-main my-admin">
			<div class="layui-tab my-tab">
				<div class="my-title-box">
					<h5 class="my-title">编辑短信接口</h5>
					<a href="javascript:history.go(-1);" class="layui-btn layui-btn-small layui-btn-normal"><i class="layui-icon">&#xe65c;</i></a>
				</div>
				<div class="my-content">
					<form method="post" class="layui-form" action="">
						<table class="layui-table">
							<colgroup>
								<col width="10%" />
								<col />
							</colgroup>
							<tr>
								<td align="right">接口名称：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="name" value="<?php echo $message['name']; ?>" lay-verify="required" class="layui-input" placeholder="接口名称" />
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">账户名：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="account" value="<?php echo $message['account']; ?>" lay-verify="required" class="layui-input" placeholder="账户名" />
										</div>
										<div class="layui-form-mid layui-word-aux">如：ling616</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">账户密码：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="password" name="password" value="<?php echo $message['password']; ?>" class="layui-input" placeholder="账户密码" />
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">短信内容：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<textarea class="layui-textarea" name="msg" placeholder="短信内容"><?php echo $message['msg']; ?></textarea>
										</div>
										<div class="layui-form-mid layui-word-aux">如：【phone】恭喜您报名成功！</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">是否开启：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-inline">
											<input type="radio" name="is_show" value="1" <?php if(($message['is_show']) == 1): ?> checked="checked" <?php endif; ?> title="开启">
  											<input type="radio" name="is_show" value="0" <?php if(($message['is_show']) == 0): ?> checked="checked" <?php endif; ?> title="关闭">
										</div>
									</div>
								</td>
							</tr>
							<input type="hidden" name="id" value="<?php echo $message['id']; ?>" />
							<tr>
								<td align="right">&nbsp;</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-inline">
											<button class="layui-btn" lay-submit="" data-url="<?php echo url('/admin/system/editmsg'); ?>" lay-filter="editlink">保存</button>
											<button type="reset" class="layui-btn layui-btn-danger">重置</button>
										</div>
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
		</div>
	</body>
	<script type="text/javascript">
		layui.config({
			base: '__PUBLIC__/admin/js/modules/' //你存放新模块的目录，注意，不是layui的模块目录
		}).use('system'); //加载入口
	</script>
</html>