<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:42:"./application/mobile/view/index\index.html";i:1528189766;s:44:"./application/mobile/view/public\header.html";i:1528187819;s:44:"./application/mobile/view/public\footer.html";i:1528266547;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta name="format-detection" content="telephone=no, email=no">
	<meta content="yes" name="apple-mobile-web-app-capable"/>
    <!-- Safari浏览器私有meta属性 -->
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-title" content="APP name">
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/mobile/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jquery-2.1.1.min.js"></script>
	<!-- <script src="__PUBLIC__/mobile/js/touch.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jsrem.js"></script>
	<script src="__PUBLIC__/mobile/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/style.css">
	<title><?php echo $website['title']; ?></title>
</head>
<body>
<head>
	<div class="head">
		<ul class="wrap">
			<li class="fl"><a href="<?php echo $website['url']; ?>/mobile"><img src="<?php echo $website['logo']; ?>"></a></li>
			<li class="fr"><p class="col000 textr font22">报名已破<span class="fontber"><?php echo $joinnum; ?></span>人<br><span class="font16">每晚6点更新数据</span></p></li>
		</ul>
	</div>
</head>
				
<!-- 首页banner -->
<article>
	<div class="banner">
	   <div class="wrap">
		 <img class="b-img1" src="__PUBLIC__/mobile/images/bicon1.png">
		 <h3 class="font40 fontb col000 textc">第六届&nbsp;&nbsp;&nbsp;&nbsp;多谢杯</h3>
		 <img class="b-img2" src="__PUBLIC__/mobile/images/bicon2.png">
		 <p class="font30 fontl col000 textc">连接你我&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;连接世界</p>
		 <a href="/mobile/online.html" class="button-sty font36 colfff textc">立即报名</a>
		 <p class="font28 textc col000 fontl">已报名<?php echo $joinnum; ?>人</p>
		 <p class="font-b font28 textc col000 fontl">7月19号<br/>郑州国际会展中心</p>
	   </div>
	   <img src="__PUBLIC__/mobile/images/bicon3.png" class="b-bgimg">
	</div>
</article>

<!-- 大会信息 -->
<article>
    <div class="meeting-info">
    	<div class="wrap">
    		<h3 class="fontb textc colfff">大会信息</h3>
    		<p class="font28 colfff">
	    		<span class="fontb">时间：</span>2018年7月19日<br/>
	    		<span class="fontb">地点：</span>郑州国际会展中心辕厅<br/>
	    		<span class="fontb">主题：</span>区块链、共享经济<br/>
	    		<span class="fontb">规模：</span>1万人<br/>
	    		<span class="fontb">招商：</span>18012345678
    	    </p>
    		<p class="font28 colfff">
    		   <span class="fontb">投诉：</span>0371-61234567<br/>
    		   <span class="fontb">QQ群：</span>河南创业者群1：56465
    	   </p>
    	</div>
    </div>
</article>

<!-- 参会嘉宾 -->
<article>
	<div class="meeting-guest bg1">
		 <div class="wrap">
		 	 <h3 class="fontb textc col000">参会嘉宾</h3>
		 	 <ul>
		 	 	<?php if(is_array($guestList) || $guestList instanceof \think\Collection || $guestList instanceof \think\Paginator): $i = 0; $__LIST__ = $guestList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
					<li>
						<div class="m-g-img">
							<img src="<?php echo $vo['thumb']; ?>" />
						</div>
						<p class="font28 textc col000"><?php echo $vo['title']; ?><br><span class="font22"><?php echo $vo['subtitle']; ?></span></p>
					</li>
				<?php endforeach; endif; else: echo "" ;endif; ?>
		 	 </ul>
		 </div>
	</div>
</article>

<!-- 合作伙伴 -->
<article>
	<div class="cooperation">
		<div class="wrap">
			<h3 class="fontb textc col000">合作伙伴</h3>
			<?php if(is_array($partList) || $partList instanceof \think\Collection || $partList instanceof \think\Paginator): $i = 0; $__LIST__ = $partList;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
				<h4 class="font26 textl col000"><?php echo $vo['name']; ?></h4>
				<ul class="clearfix">
					<?php if(is_array($vo['children']) || $vo['children'] instanceof \think\Collection || $vo['children'] instanceof \think\Paginator): $i = 0; $__LIST__ = $vo['children'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$sub): $mod = ($i % 2 );++$i;?>
						<li><img src="<?php echo $sub['thumb']; ?>"/></li>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</ul>
			<?php endforeach; endif; else: echo "" ;endif; ?>
		</div>
	</div>
</article>

<!-- 往期回顾 -->
<article>
	<div class="past-period">
		<div class="wrap" id="sliderWrap">
			<h3 class="fontb textl font40 colfff">往期回顾</h3>
			<div class="p-p-img-list clearfix">
				<ul class="clearfix">
					<li><img src="__PUBLIC__/mobile/images/iicon1.png">
						<p class="font30 colfff textc">615位<br/><span class="font18">演讲嘉宾</span></p>
					</li>
					<li><img src="__PUBLIC__/mobile/images/iicon2.png">
						<p class="font30 colfff textc">20000+<br/><span class="font18">参会人员</span></p>
					</li>
					<li><img src="__PUBLIC__/mobile/images/iicon3.png">
						<p class="font30 colfff textc">超过2万+<br/><span class="font18">参会企业</span></p>
					</li>
					<li><img src="__PUBLIC__/mobile/images/iicon4.png">
						<p class="font30 colfff textc">552位<br/><span class="font18">媒体</span></p>
					</li>
					<li><img src="__PUBLIC__/mobile/images/iicon5.png">
						<p class="font30 colfff textc">720家<br/><span class="font18">品牌参与</span></p>
					</li>
					<li><img src="__PUBLIC__/mobile/images/iicon6.png">
						<p class="font30 colfff textc">120家<br/><span class="font18">新媒体</span></p>
					</li>
					<li><img src="__PUBLIC__/mobile/images/iicon7.png">
						<p class="font30 colfff textc">700+<br/><span class="font18">稿件发布</span></p>
					</li>
					<li><img src="__PUBLIC__/mobile/images/iicon8.png">
						<p class="font30 colfff textc">3000万次+<br/><span class="font18">曝光次数</span></p>
					</li>
				</ul>
			</div>
			<div class="swiper-container clearfix">
				<div class="swiper-wrapper" style="margin: 0 0.3rem 0 0;">
					<div class="swiper-slide">
						<img src="__PUBLIC__/mobile/images/img1.jpg">
						<p class="textl colfff font26">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/mobile/images/img1.jpg">
						<p class="textl colfff font26">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/mobile/images/img1.jpg">
						<p class="textl colfff font26">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/mobile/images/img1.jpg">
						<p class="textl colfff font26">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/mobile/images/img1.jpg">
						<p class="textl colfff font26">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/mobile/images/img1.jpg">
						<p class="textl colfff font26">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/mobile/images/img1.jpg">
						<p class="textl colfff font26">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
					<div class="swiper-slide">
						<img src="__PUBLIC__/mobile/images/img1.jpg">
						<p class="textl colfff font26">第五届河南创业者大会<br/><span>5800人参会</span></p>
					</div>
				</div>
			</div>
		</div>
	</div>
</article>

<script type="text/javascript">
	$(document).ready(function() {
		var w = document.getElementById('sliderWrap').offsetWidth-50;

		var mySwiper = new Swiper ('.swiper-container', {
		    direction: 'horizontal',
		    loopedSlides: 8,
		    loop:true,
		    width: w
		  })
		
	})
</script>

<!-- 联系我们 -->
<article>
	<div class="contact-us">
		<div class="wrap">
			<h3 class="fontb textc col000">联系我们</h3>
			<ul>
				<li>
					<h4 class="fontb font36 col000 textl">会务合作</h4>
					<p class="font36 col000 fontl  fontb">张巧英</p>
					<p class="fontl col000 font28 fontb"><img src="__PUBLIC__/mobile/images/cicon1.png"><a href="tel:18337168038" class="col000">183 3716 8038</a></p>
					<p class="fontl col000 font28  fontb"><img src="__PUBLIC__/mobile/images/cicon2.png">anan@asdfsadf.com</p>	
				</li>
				<li>
					<h4 class="fontb font36 col000 textl">领票地点/报名</h4>
					<p class="font36 col000 fontl  fontb">阿牛</p>
					<p class="fontl col000 font28  fontb"><img src="__PUBLIC__/mobile/images/cicon1.png"><a href="tel:18337168038"  class="col000">183 3716 8038</a></p>
					<p class="fontl col000 font28  fontb"><img src="__PUBLIC__/mobile/images/cicon2.png">anan@asdfsadf.com</p>
				</li>
				<li>
					<h4 class="fontb font36 col000 textl">商务合作</h4>
					<p class="font36 col000 fontl  fontb">常洪涛</p>
					<p class="fontl col000 font28  fontb"><img src="__PUBLIC__/mobile/images/cicon1.png"><a href="tel:18337168038"  class="col000">183 3716 8038</a></p>
					<p class="fontl col000 font28  fontb"><img src="__PUBLIC__/mobile/images/cicon2.png">anan@asdfsadf.com</p>
				</li>
				<li>
					<h4 class="fontb font36 col000 textl">媒体合作</h4>
					<p class="font36 col000 fontl fontb">刘洋</p>
					<p class="fontl col000 font28  fontb"><img src="__PUBLIC__/mobile/images/cicon1.png"><a href="tel:18337168038"  class="col000">183 3716 8038</a></p>
					<p class="fontl col000 font28  fontb"><img src="__PUBLIC__/mobile/images/cicon2.png">anan@asdfsadf.com</p>
				</li>
			</ul><!-- text-i  -->
		</div>
	</div>
</article>
<nav>
	<div class="nav-fotter clearfix">
		<ul class="clearfix">
			<li><a href="/mobile/page/1.html">介绍</a></li>
			<li><a href="/mobile/guest.html">嘉宾</a></li>
			<li><a href="/mobile/page/2.html">议程</a></li>
			<li><a href="/mobile/place.html">领票点</a></li>
			<li><a href="/mobile/news.html">动态</a></li>
			<li class="active"><a href="/mobile/my.html">我的</a></li>
		</ul>
	</div>
</nav>
<!--尾部-->
	<footer>
		<div class="footer">
			<div class="wrap">
				<img src="__PUBLIC__/home/images/fb.png">
				<p class="textc font14 col868">©2005-2025河南创业者大会版权所有豫ICP备16026558号<br/>景安网路唯一官方指定技术支持合作商</p>
			</div>
		</div>
	</footer>
	</body>
</html>