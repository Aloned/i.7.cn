<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:40:"./application/home/view/index\index.html";i:1528093910;s:40:"./application/home/view/widget\head.html";i:1528191938;}*/ ?>

<ul class="clearfix">
	<li><a href="<?php echo $website['url']; ?>" title="<?php echo $website['title']; ?>" <?php if($nav == '0'): ?> class="active" <?php endif; ?>>首页</a></li>
	<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
		<li>
			<?php switch($vo['cat_id']): case "1":case "2": ?>
					<a href="<?php echo url('/page/'.$vo['cat_id']); ?>" title="<?php echo $vo['cat_name']; ?>" <?php if($nav == $vo['cat_id']): ?> class="active" <?php endif; ?>><?php echo $vo['cat_name']; ?></a></li>
				<?php break; case "3": ?>
					<a href="<?php echo url('/guest'); ?>" title="<?php echo $vo['cat_name']; ?>" <?php if($nav == $vo['cat_id']): ?> class="active" <?php endif; ?>><?php echo $vo['cat_name']; ?></a></li>
				<?php break; case "5": ?>
					<a href="<?php echo url('/news'); ?>" title="<?php echo $vo['cat_name']; ?>" <?php if($nav == $vo['cat_id']): ?> class="active" <?php endif; ?>><?php echo $vo['cat_name']; ?></a></li>
				<?php break; case "6": ?>
					<a href="<?php echo url('/place'); ?>" title="<?php echo $vo['cat_name']; ?>" <?php if($nav == $vo['cat_id']): ?> class="active" <?php endif; ?>><?php echo $vo['cat_name']; ?></a></li>
				<?php break; case "4":case "7": ?>
					<a href="<?php echo url('/partner/'.$vo['cat_id']); ?>" title="<?php echo $vo['cat_name']; ?>" <?php if($nav == $vo['cat_id']): ?> class="active" <?php endif; ?>><?php echo $vo['cat_name']; ?></a></li>
				<?php break; endswitch; ?>
		</li>
	<?php endforeach; endif; else: echo "" ;endif; ?>
	<li><a href="<?php echo url('/my'); ?>" title="我的" <?php if($nav == '99'): ?> class="active" <?php endif; ?>>我的</a></li>
</ul>
