<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:38:"./application/mobile/view/user\my.html";i:1528267955;s:44:"./application/mobile/view/public\header.html";i:1528187819;s:43:"./application/mobile/view/public\uside.html";i:1528274451;s:45:"./application/mobile/view/public\nfooter.html";i:1528267851;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta name="format-detection" content="telephone=no, email=no">
	<meta content="yes" name="apple-mobile-web-app-capable"/>
    <!-- Safari浏览器私有meta属性 -->
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-title" content="APP name">
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/mobile/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jquery-2.1.1.min.js"></script>
	<!-- <script src="__PUBLIC__/mobile/js/touch.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jsrem.js"></script>
	<script src="__PUBLIC__/mobile/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/style.css">
	<title>用户登录 - <?php echo $website['title']; ?></title>
</head>
<body>
<head>
	<div class="head">
		<ul class="wrap">
			<li class="fl"><a href="<?php echo $website['url']; ?>/mobile"><img src="<?php echo $website['logo']; ?>"></a></li>
			<li class="fr"><p class="col000 textr font22">报名已破<span class="fontber"><?php echo $joinnum; ?></span>人<br><span class="font16">每晚6点更新数据</span></p></li>
		</ul>
	</div>
</head>
				
<div class="banner-wrap clearfix"></div>
<!-- 个人中心 -->
<!-- 个人中心 -->
<article>
	<div class="center-head clearfix">
		<div class="wrap">
			<dl class="clearfix">
				<dt><img src="__PUBLIC__/mobile/images/bgheadimg.png"></dt>
				<dd>
					<p class="colfff font32 fontber">代用名<br/><span class="font26 fontb">普通会员</span></p>
				</dd>
			</dl>
			<ul class="clearfix">
				<li class="textc">
					<span class="font36 fontb"><?php echo inviteNumber($user['ucode']); ?></span>
					<p class="font22">好友报名数</p>
				</li>
				<li class="textc">
					<span class="font36 fontb"><?php echo invitedNumber($user['ucode']); ?></span>
					<p class="font22">好友领票数</p>
				</li>
			</ul>
		</div>
	</div>
</article>

<article>
	<div class="center-list">
		<ul class="font32">
	<li><a href="/mobile/ticket.html">我的门票</a><i><img src="__PUBLIC__/mobile/images/iconleft.png"></i></li>
	<li><a href="/mobile/person.html">个人资料</a><i><img src="__PUBLIC__/mobile/images/iconleft.png"></i></li>
	<li><a href="/mobile/invite.html">我的邀请 <span style="color:#aaa;">(赢取VIP门票)</span></a><i><img src="__PUBLIC__/mobile/images/iconleft.png"></i></li>
	<li><a href="/mobile/edit.html">修改密码</a><i><img src="__PUBLIC__/mobile/images/iconleft.png"></i></li>
	<li><a href="javascript:;" class="logout">退出</a></li>
</ul>

<script type="text/javascript">
	$(function(){
		$('.logout').click(function(){
			$.ajax({
				type: "post",
				url: "<?php echo url('/mobile/logout'); ?>",
				data: {},
				dataType: 'json',
				async: true,
				success: function(res) {
					if(res.status == 1) {
						alert(res.msg);
						window.location.href = '/';
					}
				},
				error: function(e) {
					console.log(e)
				}
			});
		});
	});
</script>

	</div>
</article>

<script type="text/javascript">
	
</script>

<nav>
	<div class="nav-fotter clearfix">
		<ul class="clearfix">
			<li><a href="/mobile/page/1.html">介绍</a></li>
			<li><a href="/mobile/guest.html">嘉宾</a></li>
			<li><a href="/mobile/page/2.html">议程</a></li>
			<li><a href="/mobile/place.html">领票点</a></li>
			<li><a href="/mobile/news.html">动态</a></li>
			<li class="active"><a href="/mobile/my.html">我的</a></li>
		</ul>
	</div>
</nav>
	</body>
</html>