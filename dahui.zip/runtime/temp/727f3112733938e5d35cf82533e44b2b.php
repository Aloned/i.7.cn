<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:39:"./application/admin/view/store\add.html";i:1527565748;}*/ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">
		<title>主页</title>

		<!--CSS-->
		<link rel="stylesheet" href="__PUBLIC__/plugins/layui/css/layui.css" />
		<link rel="stylesheet" href="__PUBLIC__/admin/css/global.css" />

		<!--JS-->
		<script type="text/javascript" src="__PUBLIC__/plugins/layui/layui.js"></script>
		<script type="text/javascript" src="__PUBLIC__/admin/js/jquery.min.js"></script>
	</head>

	<body>
		<div class="layui-main my-admin">
			<div class="layui-tab my-tab">
				<div class="my-title-box">
					<h5 class="my-title">添加领票点</h5>
					<a href="javascript:history.go(-1);" class="layui-btn layui-btn-small layui-btn-normal"><i class="layui-icon">&#xe65c;</i></a>
				</div>
				<div class="my-content">
					<form method="post" class="layui-form" action="">
						<table class="layui-table">
							<colgroup>
								<col width="10%" />
								<col />
							</colgroup>
							<tr>
								<td align="right">所在城市：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<select name="store_city" id="store_city" lay-filter="store_city">
			                                    <?php if(is_array($citylist) || $citylist instanceof \think\Collection || $citylist instanceof \think\Paginator): $i = 0; $__LIST__ = $citylist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>                                            
			                                        <option value="<?php echo $vo['cityname']; ?>"><?php echo $vo['cityname']; ?></option>
			                                    <?php endforeach; endif; else: echo "" ;endif; ?>                                            
											</select>
										</div>
										<div class="layui-form-mid layui-word-aux">选择城市</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">领票点名称：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="store_name" lay-verify="required" class="layui-input" placeholder="领票点名称" />
										</div>
										<div class="layui-form-mid layui-word-aux">如：宋唐好文玩</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">联系人：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="store_contact" class="layui-input" placeholder="联系人" />
										</div>
										<div class="layui-form-mid layui-word-aux">如：张三</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">电话：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="store_tel" class="layui-input" placeholder="电话" />
										</div>
										<div class="layui-form-mid layui-word-aux">如：13598834300</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">分配票数：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="store_amount" class="layui-input" placeholder="分配票数" />
										</div>
										<div class="layui-form-mid layui-word-aux">如：100</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">领票点地址：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<textarea name="store_address" class="layui-textarea" placeholder="领票点地址"></textarea>
										</div>
										<div class="layui-form-mid layui-word-aux">如：郑州市花园路31号</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">领票点介绍：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<textarea name="store_desc" class="layui-textarea" placeholder="领票点介绍"></textarea>
										</div>
										<div class="layui-form-mid layui-word-aux">如：这是一个牛逼的领票点</div>
									</div>
								</td>
							</tr>
							
							<tr>
								<td align="right">是否显示：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="radio" name="is_show" value="1" title="是" checked="checked">
  											<input type="radio" name="is_show" value="0" title="否">
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">&nbsp;</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<button class="layui-btn" lay-submit="" data-url="<?php echo url('/admin/store/add'); ?>" lay-filter="add">保存</button>
											<button type="reset" class="layui-btn layui-btn-danger">重置</button>
										</div>
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
		</div>
	</body>
	<script type="text/javascript">
		layui.config({
			base: '__PUBLIC__/admin/js/modules/' //你存放新模块的目录，注意，不是layui的模块目录
		}).use('store'); //加载入口
	</script>
	<script type="text/javascript">		
		// 选择商品返回
		function call_back(table_html) {
			//$('.cka').css('display','none');
			$('#goods').empty().html('<table class="layui-table">' + table_html + '</table>');
			//过滤选择重复商品
			
			// 已拥有id
			var ids = new Array();
			$('input[name*="pid"]').each(function(i, o) {
				ids[i] = $(o).data('id');
			});
			if(isal(ids)){
				layer.msg('有重复产品插入，你注意');
				for(var i=0; i<ids.length;i++){
					$('#goods').find('input[data-id ='+ids[i]+']').parent('div').parent('td').parent('tr').remove();
				}
				
			}
			layer.closeAll('iframe');
		}
		
		function isal(a){
		   return /(\x0f[^\x0f]+)\x0f[\s\S]*\1/.test("\x0f"+a.join("\x0f\x0f") +"\x0f");
		}
	</script>
</html>