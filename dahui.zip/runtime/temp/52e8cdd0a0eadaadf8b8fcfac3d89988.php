<?php if (!defined('THINK_PATH')) exit(); /*a:4:{s:36:"./application/home/view/user\my.html";i:1528257563;s:42:"./application/home/view/public\header.html";i:1528189644;s:41:"./application/home/view/public\uside.html";i:1528264800;s:42:"./application/home/view/public\footer.html";i:1528257730;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/home/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/home/js/jquery.min.js"></script>
	<!-- <script src="__PUBLIC__/home/js/touch.js"></script> -->
	<script src="__PUBLIC__/home/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/style.css">
	<script type="text/javascript">if(window.location.toString().indexOf('pref=padindex') != -1){}else{if(/AppleWebKit.*Mobile/i.test(navigator.userAgent) || (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/.test(navigator.userAgent))){if(window.location.href.indexOf("?mobile")<0){try{if(/Android|Windows Phone|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)){window.location.href="/mobile";}else if(/iPad/i.test(navigator.userAgent)){}else{}}catch(e){}}}}</script>
	<title>用户登录 - <?php echo $website['title']; ?></title>
</head>
<body>
<head>
	<div class="head">
		<div class="wrap">
			<div class="fl logo"><a href="<?php echo $website['url']; ?>"><img src="<?php echo $website['logo']; ?>"></a></div>
			<div class="fr nav">
				<?php echo widget('widget/head'); ?>
			</div>
			<p class="col000 textr font14 head-pos">报名已破<span class="fontber"><?php echo $joinnum; ?></span>人<br><span class="font12 col7e">每晚6点更新数据</span></p>
		</div>
	</div>
</head>
				
<div class="banner-wrap clearfix"></div>
<!-- 个人中心 -->
<div class="wrap clearfix">
	<div class="box-left fl">
		<ul class="side-nav">
	<li><a href="/my.html" <?php if($nav2 == '1'): ?>class="active"<?php endif; ?> >我的门票</a></li>
	<li><a href="/person.html" <?php if($nav2 == '2'): ?>class="active"<?php endif; ?> >个人资料</a></li>
	<li><a href="/my.html" <?php if($nav2 == '3'): ?>class="active"<?php endif; ?> >我的邀请</a></li>
	<li><a href="javascript:;" class="logout">退出</a></li>
</ul>

<script type="text/javascript">
	$(function(){
		$('.logout').click(function(){
			$.ajax({
				type: "post",
				url: "<?php echo url('login/logout'); ?>",
				data: {},
				dataType: 'json',
				async: true,
				success: function(res) {
					if(res.status == 1) {
						alert(res.msg);
						window.location.href = '/';
					}
				},
				error: function(e) {
					console.log(e)
				}
			});
		});
	});
</script>

	</div>
	<div class="box-right fr">
		<div class="conl clearfix">
			<ul class="clearfix">
				<li class="font32 textc active">我的邀请</li>
				<li class="font32 textc">邀请排行</li>
			</ul>
		</div>
		<div class="conl-cont clearfix" id="conlCont0">
			<div class="record-info">
				<h3>我的战绩</h3>
				<ul class="clearfix">
					<li><span><?php echo inviteNumber($user['ucode']); ?></span><br/>好友报名数</li>
					<li><span><?php echo invitedNumber($user['ucode']); ?></span><br/>好友领票数</li>
				</ul>
				<p class="textc col000 font14">还差<?php echo poorNumber($user['ucode']); ?>人即可升级门票为VIP门票</p>
				<a href="javascript:;" class="yqhyBtn">去邀请</a>
			</div>
			<div class="invitation-list">
				<h3>我邀请的人</h3>
				<ul class="clearfix">
					<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "您还没有邀请哦" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<li class="clearfix"><span class="fl font16 col000"><?php echo $vo['uname']; ?></span><span class="fr font14 col7e"><?php echo date("Y-m-d H:i:s",$vo['addtime']); ?></span></li>
					<?php endforeach; endif; else: echo "您还没有邀请哦" ;endif; ?>
				</ul>
			</div>
		</div>
		<div class="conl-cont clearfix" id="conlCont1" style="display: none;">
			<div class="myinvitation-cont clearfix">
				<h4 class="col000 textl">当前排名第2位</h4>
				<p class="col000 textl font16">截止7月18日中午12:00,邀请满10名好友领票可升级为大会VIP,领取VIP票,邀请报名数及邀请领票数前100名将分别获得大会提供的"逐梦礼包"和"奋斗大礼包"</p>
                <a href="javascript:;" class="yqhyBtn">去邀请</a>
		    </div>
		    <div class="myinvitation-list clearfix">
			    <h3 class="textc font26 col000">邀请排行榜</h3>
				<table class="myinvitation-table">
					<thead>
						<td>排名</td>
						<td>用户</td>
						<td>邀请人数</td>
						<td>已领门票</td>
					</thead>
					<?php if(is_array($sortlist) || $sortlist instanceof \think\Collection || $sortlist instanceof \think\Paginator): $i = 0; $__LIST__ = $sortlist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
						<tr <?php if($user['uid'] == $vo['uid']): ?>class="active" <?php endif; ?> >
							<td><?php echo $i; ?></td>
							<td><?php echo $vo['name']; ?></td>
							<td><?php echo $vo['invite']; ?></td>
							<td><?php echo $vo['invited']; ?></td>
						</tr>
					<?php endforeach; endif; else: echo "" ;endif; ?>
				</table>
		    </div>
		</div>
	</div>
</div>


<!-- 提示框 -->
<div class="prompt-box">
	<div class="prompt-cont">
		 <h3>邀请好友</h3>
		 <p>复制链接发给好友，让大家知道这个热血澎湃，充满希望的集会</p>
		 <p class="textc" id="content"><?php echo $website['url']; ?>/online.html?ufrom=<?php echo $user['ucode']; ?></p>
		 <a href="javascript:;" id="copyBT" data-clipboard-text="<?php echo $website['url']; ?>/online.html?ufrom=<?php echo $user['ucode']; ?>"><span>复制链接</span></a>
		 <p class="textc fontb font32">赢VIP门票，创业大会大礼包</p>
	</div>
</div>

<script type="text/javascript">
	$('.yqhyBtn').bind('click',function(){
		$('.prompt-box').show();
	});
	$('.prompt-box').bind('click',function(){
		$('.prompt-box').hide();
	});
	$('.prompt-cont').bind('click',function(event){
		event.stopPropagation();
	});
	$('.prompt-cont a').bind('click',function(event){
		
	});
	
	function tab(){
		var conlLi = $('.conl li');
	
		conlLi.bind('click',function(){
			 var _index = $(this).index();
			 $(this).addClass('active').siblings().removeClass('active');
			 $('.conl-cont').hide();
			 $('#conlCont'+_index).show();
		})
	}
	
	tab();
	
    function copyArticle(event) {
        const range = document.createRange();
        range.selectNode(document.getElementById('content'));
 
        const selection = window.getSelection();
        if(selection.rangeCount > 0) selection.removeAllRanges();
        selection.addRange(range);
        document.execCommand('copy');
        alert("复制成功！");
    }
 
    document.getElementById('copyBT').addEventListener('click', copyArticle, false);
</script>

<!--尾部-->
	<footer>
		<div class="footer">
			<div class="wrap">
				<img src="__PUBLIC__/home/images/fb.png">
				<p class="textc font14 col868">©2005-2025河南创业者大会版权所有豫ICP备16026558号<br/>景安网路唯一官方指定技术支持合作商</p>
			</div>
		</div>
	</footer>
	</body>
</html>