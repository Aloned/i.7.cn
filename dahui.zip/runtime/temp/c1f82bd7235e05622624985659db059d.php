<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:42:"./application/admin/view/system\index.html";i:1527581054;}*/ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">
		<title>主页</title>

		<!--CSS-->
		<link rel="stylesheet" href="__PUBLIC__/plugins/layui/css/layui.css" />
		<link rel="stylesheet" href="__PUBLIC__/admin/css/global.css" />

		<!--JS-->
		<script type="text/javascript" src="__PUBLIC__/plugins/layui/layui.js"></script>
	</head>

	<body>
		<div class="layui-main my-admin">
			<div class="layui-tab my-tab">
				<div class="my-title-box">
					<h5 class="my-title">网站设置</h5>
				</div>
				<div class="my-content">
					<form method="post" class="layui-form" action="">
						<table class="layui-table">
							<colgroup>
								<col width="10%" />
								<col />
							</colgroup>
							<tr>
								<td align="right">网站地址：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="url" lay-verify="required|url" value="<?php echo $config['url']; ?>" class="layui-input" placeholder="网站地址" />
										</div>
										<div class="layui-form-mid layui-word-aux">如：http://www.haowenwan.com/</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">网站标题：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="title" lay-verify="required" value="<?php echo $config['title']; ?>" class="layui-input" placeholder="网站标题" />
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">网站LOGO：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="logo" lay-verify="required" value="<?php echo $config['logo']; ?>" class="layui-input" placeholder="网站logo" />
										</div>
										
										<a href="javascript:;" class="layui-btn" id="uploadlogo">上传</a>
										<img alt="LOGO" src="<?php echo $config['logo']; ?>" height="38"/>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">关键词：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="keywords" value="<?php echo $config['keywords']; ?>" class="layui-input" placeholder="网站关键词" />
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">备案号：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="copy" class="layui-input" value="<?php echo $config['copy']; ?>" placeholder="网站备案号" />
										</div>
										<div class="layui-form-mid layui-word-aux">如：豫ICP备 123456</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">联系电话：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="tel" class="layui-input" value="<?php echo $config['tel']; ?>" placeholder="联系电话" />
										</div>
										<div class="layui-form-mid layui-word-aux">如：13598834300</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">QQ：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="qq" class="layui-input" value="<?php echo $config['qq']; ?>" placeholder="qq" />
										</div>
										<div class="layui-form-mid layui-word-aux">如：97398302</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">公司地址：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="address" class="layui-input" value="<?php echo $config['address']; ?>" placeholder="公司地址" />
										</div>
										<div class="layui-form-mid layui-word-aux">如：河南省郑州市中原区</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">网站描述：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<textarea class="layui-textarea" name="content" placeholder="网站描述"><?php echo $config['content']; ?></textarea>
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">&nbsp;</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-inline">
											<button class="layui-btn" lay-submit="" data-url="<?php echo url('/admin/system/updateConfig'); ?>" lay-filter="config">保存</button>
											<button type="reset" class="layui-btn layui-btn-danger">重置</button>
										</div>
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
		</div>
	</body>
	<script type="text/javascript">
		layui.config({
			base: '__PUBLIC__/admin/js/modules/' //你存放新模块的目录，注意，不是layui的模块目录
		}).use('system'); //加载入口
	</script>
</html>