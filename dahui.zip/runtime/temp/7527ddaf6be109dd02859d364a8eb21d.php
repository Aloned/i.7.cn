<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:50:"./application/admin/view/category\addcategory.html";i:1514535396;}*/ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">
		<title>主页</title>

		<!--CSS-->
		<link rel="stylesheet" href="__PUBLIC__/plugins/layui/css/layui.css" />
		<link rel="stylesheet" href="__PUBLIC__/admin/css/global.css" />

		<!--JS-->
		<script type="text/javascript" src="__PUBLIC__/plugins/layui/layui.js"></script>
	</head>

	<body>
		<div class="layui-main my-admin">
			<div class="layui-tab my-tab">
				<div class="my-title-box">
					<h5 class="my-title">添加分类</h5>
					<a href="javascript:history.go(-1);" class="layui-btn layui-btn-small layui-btn-normal"><i class="layui-icon">&#xe65c;</i></a>
				</div>
				<div class="my-content">
					<form method="post" class="layui-form" action="">
						<table class="layui-table">
							<colgroup>
								<col width="10%" />
								<col />
							</colgroup>
							<tr>
								<td align="right">分类名称：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="cat_name" lay-verify="required" class="layui-input" placeholder="分类名称" />
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">选择模型：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line" style="width: auto;">
											<?php if(is_array($module_list) || $module_list instanceof \think\Collection || $module_list instanceof \think\Paginator): $i = 0; $__LIST__ = $module_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$module): $mod = ($i % 2 );++$i;?>                                            
		                                        <input type="radio" name="mod_id" value="<?php echo $module['id']; ?>" lay-filter="module" <?php if($module['id'] == 1): ?>checked="checked"<?php endif; ?> title="<?php echo $module['name']; ?>">
		                                    <?php endforeach; endif; else: echo "" ;endif; ?>
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">上级分类：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<select name="parent_id_1" id="parent_id_1" lay-filter="parent_id_1">
			                                    <option value="0">顶级分类</option>
			                                    <?php if(is_array($cat_list) || $cat_list instanceof \think\Collection || $cat_list instanceof \think\Paginator): $i = 0; $__LIST__ = $cat_list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>                                            
			                                        <option value="<?php echo $vo['cat_id']; ?>"><?php echo $vo['cat_name']; ?></option>
			                                    <?php endforeach; endif; else: echo "" ;endif; ?>                                            
											</select>
										</div>
										<div class="layui-input-inline">
											<select name="parent_id_2" id="parent_id_2" lay-filter="parent_id_2">
			                                	<option value="0">请选择分类</option>
			                              	</select> 
										</div>
										<div class="layui-form-mid layui-word-aux">选择父级分类</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">分类图片：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="cat_thumb" class="layui-input" placeholder="分类图片" />
										</div>
										<a href="javascript:;" class="layui-btn" id="uploadcimg">上传</a>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">排序：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="sort_order" lay-verify="required" class="layui-input" placeholder="排序" />
										</div>
										<div class="layui-form-mid layui-word-aux">正序排序，越小越靠前</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">导航显示：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="radio" name="is_show" value="1" title="是" checked="checked">
  											<input type="radio" name="is_show" value="0" title="否">
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">是否推荐：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="radio" name="is_hot" value="1" title="是">
  											<input type="radio" name="is_hot" value="0" title="否" checked="checked">
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">分类描述：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<textarea name="cat_desc" class="layui-textarea" placeholder="分类描述"></textarea>
										</div>
										<div class="layui-form-mid layui-word-aux">对分类做一个介绍吧</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">&nbsp;</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<button class="layui-btn" lay-submit="" data-url="<?php echo url('/admin/category/addcategory'); ?>" lay-filter="addcategory">保存</button>
											<button type="reset" class="layui-btn layui-btn-danger">重置</button>
										</div>
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
		</div>
	</body>
	<script type="text/javascript">
		layui.config({
			base: '__PUBLIC__/admin/js/modules/' //你存放新模块的目录，注意，不是layui的模块目录
		}).use('category'); //加载入口
	</script>
</html>