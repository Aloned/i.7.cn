<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:39:"./application/home/view/user\login.html";i:1528265740;s:42:"./application/home/view/public\header.html";i:1528189644;s:42:"./application/home/view/public\footer.html";i:1528257730;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $website['keywords']; ?>" />
	<meta name="description" content="<?php echo $website['content']; ?>" />
	<!-- <script src="__PUBLIC__/home/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/home/js/jquery.min.js"></script>
	<!-- <script src="__PUBLIC__/home/js/touch.js"></script> -->
	<script src="__PUBLIC__/home/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/home/style/style.css">
	<script type="text/javascript">if(window.location.toString().indexOf('pref=padindex') != -1){}else{if(/AppleWebKit.*Mobile/i.test(navigator.userAgent) || (/MIDP|SymbianOS|NOKIA|SAMSUNG|LG|NEC|TCL|Alcatel|BIRD|DBTEL|Dopod|PHILIPS|HAIER|LENOVO|MOT-|Nokia|SonyEricsson|SIE-|Amoi|ZTE/.test(navigator.userAgent))){if(window.location.href.indexOf("?mobile")<0){try{if(/Android|Windows Phone|webOS|iPhone|iPod|BlackBerry/i.test(navigator.userAgent)){window.location.href="/mobile";}else if(/iPad/i.test(navigator.userAgent)){}else{}}catch(e){}}}}</script>
	<title>用户登录 - <?php echo $website['title']; ?></title>
</head>
<body>
<head>
	<div class="head">
		<div class="wrap">
			<div class="fl logo"><a href="<?php echo $website['url']; ?>"><img src="<?php echo $website['logo']; ?>"></a></div>
			<div class="fr nav">
				<?php echo widget('widget/head'); ?>
			</div>
			<p class="col000 textr font14 head-pos">报名已破<span class="fontber"><?php echo $joinnum; ?></span>人<br><span class="font12 col7e">每晚6点更新数据</span></p>
		</div>
	</div>
</head>
				
<div class="banner-wrap clearfix"></div>

<!-- 报名 -->

<article>
	<div class="user-login">
		<h3 class="textc fontb font36 col000">登录</h3>
		<div class="wrap">
			<dl class="clearfix formstyle">
				<dt class="textr">手机</dt>
				<dd><input type="text" name="utel" placeholder="请输入您的手机号" class="input1 phoneInput"></dd>
			</dl>
			<dl class="clearfix formstyle">
				<dt class="textr">密码</dt>
				<dd>
					<input type="password" name="password" placeholder="请输入您的密码" class="input1 codeInput">
				</dd>
			</dl>
			<dl class="clearfix formstyle">
				<dt>&nbsp;</dt>
				<dd>
					<a href="javascript:;" class="user-login-btn nextstep">登录</a>
				</dd>
			</dl>
		</div>
	</div>
</article>

<script type="text/javascript">
	var myreg = /^(((13[0-9]{1})|(15[0-9]{1})|(18[0-9]{1})|(17[0-9]{1}))+\d{8})$/;
	var sendBtn = $('.sendbtn');
	var phoneInput = $('.phoneInput'); //手机号
	var codeInput = $('.codeInput'); //验证码
	var loginBtn = $('.user-login-btn'); //下一步

	// 判断手机号是否正确
	function isTel(phoneInput) {
		var valuePhone = phoneInput.val();
		if(valuePhone.length == 11 && myreg.test(valuePhone)) {
			return true;
		} else {
			alert("输入手机有误，请重新输入！");
			return false;
		}
	}

	// 下一步 验证  手机号 和验证码填写是否正确
	function mobileverification() {
		var tpl = $(".phoneInput").val();
		var mycode = $(".codeInput").val();
		if(!tpl) {
			alert('请输入电话号码');
			return false;
		}
		if(!mycode) {
			alert('请输入密码');
			return false;
		}
		$.ajax({
			type: "post",
			url: "<?php echo url('/login'); ?>",
			data: {
				'utel': phoneInput.val(),
				'password':	mycode
			},
			dataType: 'json',
			async: true,
			success: function(res) {
				if(res.status == 1001) {
					window.location.href = res.url;
				}else{
					alert(res.msg);
				}
			},
			error: function(e) {
				console.log(e)
			}
		});
	}


	// 下一步
	$('.nextstep').click(function() {
		mobileverification();
	});
</script>

<!--尾部-->
	<footer>
		<div class="footer">
			<div class="wrap">
				<img src="__PUBLIC__/home/images/fb.png">
				<p class="textc font14 col868">©2005-2025河南创业者大会版权所有豫ICP备16026558号<br/>景安网路唯一官方指定技术支持合作商</p>
			</div>
		</div>
	</footer>
	</body>
</html>