<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:49:"./application/admin/view/content\editcontent.html";i:1515404066;}*/ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">
		<title>主页</title>

		<!--CSS-->
		<link rel="stylesheet" href="__PUBLIC__/plugins/layui/css/layui.css" />
		<link rel="stylesheet" href="__PUBLIC__/admin/css/global.css" />

		<!--JS-->
		<script type="text/javascript" src="__PUBLIC__/plugins/layui/layui.js"></script>
	</head>

	<body>
		<div class="layui-main my-admin">
			<div class="layui-tab my-tab">
				<div class="my-title-box">
					<h5 class="my-title">编辑单页</h5>
					<a href="javascript:history.go(-1);" class="layui-btn layui-btn-small layui-btn-normal"><i class="layui-icon">&#xe65c;</i></a>
				</div>
				<div class="my-content">
					<form method="post" class="layui-form" action="">
						<table class="layui-table">
							<colgroup>
								<col width="10%" />
								<col />
							</colgroup>
							<tr>
								<td align="right">标题：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="title" class="layui-input layui-disabled" readonly="readonly" value="<?php echo $category['cat_name']; ?>" placeholder="单页标题" />
										</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">关键字：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<input type="text" name="keywords" value="<?php echo $content['keywords']; ?>" class="layui-input" placeholder="关键字" />
										</div>
										<div class="layui-form-mid layui-word-aux">关键字设置的牛逼，有助于提升排名的哟，多个用“,”隔开</div>
									</div>
								</td>
							</tr>
							<tr>
								<td align="right">简短描述：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<textarea type="text" name="description" class="layui-textarea" placeholder="简短描述"><?php echo $content['description']; ?></textarea>
										</div>
										<div class="layui-form-mid layui-word-aux">这里就是摘要了</div>
									</div>
								</td>
							</tr>
							
							<tr>
								<td align="right">单页内容：</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-block" style="margin-left: 0;">
											<textarea name="content" lay-verify="content" id="content" placeholder="输入内容"><?php echo $content['content']; ?></textarea>
										</div>
									</div>
								</td>
							</tr>
							<input type="hidden" name="cat_id" value="<?php echo $category['cat_id']; ?>" />
							<tr>
								<td align="right">&nbsp;</td>
								<td>
									<div class="layui-form-item">
										<div class="layui-input-inline my-input-line">
											<button class="layui-btn" lay-submit="" data-url="<?php echo url('/admin/content/editcontent'); ?>" lay-filter="editcontent">保存</button>
											<button type="reset" class="layui-btn layui-btn-danger">重置</button>
										</div>
									</div>
								</td>
							</tr>
						</table>
					</form>
				</div>
			</div>
		</div>
	</body>
	<script type="text/javascript">
		layui.config({
			base: '__PUBLIC__/admin/js/modules/' //你存放新模块的目录，注意，不是layui的模块目录
		}).use('content'); //加载入口
	</script>
</html>