<?php if (!defined('THINK_PATH')) exit(); /*a:3:{s:44:"./application/mobile/view/address\index.html";i:1528187416;s:44:"./application/mobile/view/public\header.html";i:1528187819;s:44:"./application/mobile/view/public\footer.html";i:1528266547;}*/ ?>
<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge"/>
	<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate"/>
	<meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
    <meta name="format-detection" content="telephone=no, email=no">
	<meta content="yes" name="apple-mobile-web-app-capable"/>
    <!-- Safari浏览器私有meta属性 -->
	<meta name="apple-mobile-web-app-capable" content="yes">
	<meta name="apple-mobile-web-app-status-bar-style" content="black">
	<meta name="apple-mobile-web-app-title" content="APP name">
	<meta name="author" content="宋唐科技">
	<meta name="keywords" content="<?php echo $detail['keywords']; ?>" />
	<meta name="description" content="<?php echo $detail['description']; ?>" />
	<!-- <script src="__PUBLIC__/mobile/js/hotcss.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jquery-2.1.1.min.js"></script>
	<!-- <script src="__PUBLIC__/mobile/js/touch.js"></script> -->
	<script src="__PUBLIC__/mobile/js/jsrem.js"></script>
	<script src="__PUBLIC__/mobile/js/swiper.js"></script>
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/reset.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/swiper.min.css">
	<link rel="stylesheet" type="text/css" href="__PUBLIC__/mobile/style/style.css">
	<title><?php echo $detail['title']; ?> - <?php echo $website['title']; ?></title>
</head>
<body>
<head>
	<div class="head">
		<ul class="wrap">
			<li class="fl"><a href="<?php echo $website['url']; ?>/mobile"><img src="<?php echo $website['logo']; ?>"></a></li>
			<li class="fr"><p class="col000 textr font22">报名已破<span class="fontber"><?php echo $joinnum; ?></span>人<br><span class="font16">每晚6点更新数据</span></p></li>
		</ul>
	</div>
</head>
				
	<div class="banner-wrap clearfix"></div>
		
	<!-- 领票点 -->
	<article>
		<div class="ticket-point">
			<div class="wrap">
			 	<h3 class="fontb textc col000"><?php echo $detail['title']; ?></h3>
			 	<p class="font22 col000">
		    		<?php echo $detail['content']; ?>
	    	    </p>
			</div>
		</div>
		<!-- 地点详情 -->
		<article>
			<div class="wrap clearfix">
					<!--<div class="conl clearfix">
						<ul class="clearfix">
							<li class="font32 textc active">郑州</li>
							<li class="font32 textc">其他地区</li>
						</ul>
					</div>-->
					<div class="conl-cont clearfix" id="conlCont0">
						<div class="select-area">
							<?php if(is_array($citylist) || $citylist instanceof \think\Collection || $citylist instanceof \think\Paginator): $i = 0; $__LIST__ = $citylist;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
								<a href="<?php echo url('/mobile/address/'.$vo['id']); ?>" id="<?php echo $cityid; ?>" <?php if($vo['id'] == $cityid): ?>class="active"<?php endif; ?> ><?php echo $vo['cityname']; ?></a>
							<?php endforeach; endif; else: echo "" ;endif; ?>
						</div>
						<?php if(is_array($list) || $list instanceof \think\Collection || $list instanceof \think\Paginator): $i = 0; $__LIST__ = $list;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
							<div class="select-info <?php if(($i-1) == 0): ?>bor0<?php endif; ?>">
								<div class="select-show">
									<p class="font28">
										领票点<?php echo $i; ?><span class="colf0">余票：<?php echo $vo['store_amount'] - specTicket($vo['store_id']); ?></span>
									</p>
									<p class="font28 fontb"><?php echo $vo['store_address']; ?></p>
									<i><img src="__PUBLIC__/mobile/images/iconhide.png"></i>
								</div>
								<div class="select-hide">
									<p class="font16 col000"><span class="fontber"><?php echo $vo['store_name']; ?></span><br/><span class="col7e">联系人：<?php echo $vo['store_contact']; ?><br/>电话：<?php echo $vo['store_tel']; ?></span></p>
								</div>
							</div>
						<?php endforeach; endif; else: echo "" ;endif; ?>
					</div>
					<!--<div class="conl-cont clearfix" id="conlCont1" style="display: none;">
						<ul class="select-area">
							<li>其他地区</li>
							<li>经开区</li>
							<li>高新区</li>
							<li>惠济区</li>
							<li>金水区</li>
							<li>二七区</li>
							<li>管城区</li>
							<li>中原区</li>
						</ul>
						<div class="select-info bor0">
							<div class="select-show">
								<p class="font16 col7e">
									<span class="marginr30">取票地点002</span> <span class="col000">商务内环路25号楼2单元1802室</span>
		                            <i class="fr"><span class="colf0 font16">余票：20</span><img src="images/iconhide.png"></i>
								</p>
							</div>
							<div class="select-hide">
								<p class="font16 col000"><span class="fontber">河南万宝华盛人力资源服务有限公司</span><br/><span class="col7e">联系人：赵新芳<br/>电话：15965465460</span></p>
							</div>
						</div>
						<div class="select-info">
							<div class="select-show">
								<p class="font16 col7e">
									<span class="marginr30">取票地点002</span> <span class="col000">商务内环路25号楼2单元1802室</span>
		                            <i class="fr"><span class="colf0 font16">余票：20</span><img src="images/iconhide.png"></i>
								</p>
							</div>
							<div class="select-hide">
								<p class="font16 col000"><span class="fontber">河南万宝华盛人力资源服务有限公司</span><br/><span class="col7e">联系人：赵新芳<br/>电话：15965465460</span></p>
							</div>
						</div>
						<div class="select-info">
							<div class="select-show">
								<p class="font16 col7e">
									<span class="marginr30">取票地点002</span> <span class="col000">商务内环路25号楼2单元1802室</span>
		                            <i class="fr"><span class="colf0 font16">余票：20</span><img src="images/iconhide.png"></i>
								</p>
							</div>
							<div class="select-hide">
								<p class="font16 col000"><span class="fontber">河南万宝华盛人力资源服务有限公司</span><br/><span class="col7e">联系人：赵新芳<br/>电话：15965465460</span></p>
							</div>
						</div>
					</div>-->
		    </div>
		</article>
	</article>
	<script src="__PUBLIC__/home/js/my.js"></script>
	<script type="text/javascript">
			$('.select-show').bind('click',function(){
		        if ($(this).next().is(':hidden')) {
		         	$(this).children().next().next().children().attr('src','__PUBLIC__/mobile/images/iconshow.png')
		         	$(this).next().show();
		        }else{
		         	$(this).next().hide();
		         	$(this).children().next().next().children().attr('src','__PUBLIC__/mobile/images/iconhide.png')
		        }
			});
	
		$('.select-area li').bind('click',function(){
	        $(this).addClass('active').siblings().removeClass('active');
		})
	</script>
<nav>
	<div class="nav-fotter clearfix">
		<ul class="clearfix">
			<li><a href="/mobile/page/1.html">介绍</a></li>
			<li><a href="/mobile/guest.html">嘉宾</a></li>
			<li><a href="/mobile/page/2.html">议程</a></li>
			<li><a href="/mobile/place.html">领票点</a></li>
			<li><a href="/mobile/news.html">动态</a></li>
			<li class="active"><a href="/mobile/my.html">我的</a></li>
		</ul>
	</div>
</nav>
<!--尾部-->
	<footer>
		<div class="footer">
			<div class="wrap">
				<img src="__PUBLIC__/home/images/fb.png">
				<p class="textc font14 col868">©2005-2025河南创业者大会版权所有豫ICP备16026558号<br/>景安网路唯一官方指定技术支持合作商</p>
			</div>
		</div>
	</footer>
	</body>
</html>