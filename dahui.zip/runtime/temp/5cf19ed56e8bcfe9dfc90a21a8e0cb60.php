<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:40:"./application/admin/view/index\main.html";i:1527584543;}*/ ?>
<!DOCTYPE html>
<html>

	<head>
		<meta charset="UTF-8">
		<meta name="renderer" content="webkit">
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
		<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="format-detection" content="telephone=no">
		<title>主页</title>

		<!--CSS-->
		<link rel="stylesheet" href="__PUBLIC__/plugins/layui/css/layui.css" />
		<link rel="stylesheet" href="__PUBLIC__/admin/css/global.css" />

		<!--JS-->
		<script type="text/javascript" src="__PUBLIC__/plugins/layui/layui.js"></script>
		<script type="text/javascript" src="__PUBLIC__/plugins/echarts/echarts.common.min.js"></script>
	</head>

	<body>
		<div class="layui-main layui-row my-admin layui-col-space10" style="margin: 5px 10px;">
			<?php if(session('role_id') == 1): ?>
				<div class="layui-tab layui-col-xs6">
					<div class="my-tab">
						<div class="my-title-box">
							<h5 class="my-title">报名概览<span class="txt-color4" style="font-size: 12px; font-weight: normal;">（报名总人数：<?php echo signTotal(); ?>）</span></h5>
						</div>
						<div class="my-content" style="padding: 7px 20px;">
							<div id="visittime" data-time='<?php echo $visittime; ?>' style="display: none;"></div>
							<div id="pvdata" data-visit='<?php echo $pvvisit; ?>' style="display: none;"></div>
							<div id="visitSummary" style="height: 327px;"></div>
						</div>
					</div>
				</div>
				<div class="layui-tab layui-col-xs6">
					<div class="my-tab">
						<div class="my-title-box">
							<h5 class="my-title">访问统计</h5>
						</div>
						<div class="my-content" style="padding: 7px 20px;">
							<table class="layui-table my-table" lay-size="lg">
								<tbody>
									<tr>
										<th>日期</th>
										<th>浏览次数</th>
										<th>独立访客</th>
										<th>PC</th>
										<th>WAP</th>
										<th>IP</th>
									</tr>
									<tr>
		                                <td>今天</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>127</td>      
		                            </tr>
		                            <tr>
		                                <td>昨天</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>127</td>      
		                            </tr>
		                            <tr>
		                                <td>2018-1-19</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>127</td>      
		                            </tr>
		                            <tr>
		                                <td>2018-1-18</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>127</td>      
		                            </tr>
		                            <tr>
		                                <td>2018-1-17</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>12</td>
		                                <td>22</td>      
		                            </tr>
		                        </tbody>
							</table>
						</div>
					</div>
				</div>
			<?php endif; ?>
			<div class="layui-tab layui-col-xs12">
				<div class="my-tab">
					<div class="my-title-box">
						<h5 class="my-title">系统信息</h5>
					</div>
					<div class="my-content">
						<table class="layui-table my-table" lay-size="lg">
							<tbody>
								<tr>
	                                <td>服务器操作系统：</td>
	                                <td><?php echo $sys_info['os']; ?></td>
	                                <td>服务器域名/IP：</td>
	                                <td><?php echo $sys_info['domain']; ?> [ <?php echo $sys_info['ip']; ?> ]</td> 
	                                <td>服务器环境：</td> 
	                                <td><?php echo $sys_info['web_server']; ?></td>       
	                            </tr> 
	                            <tr>
	                                <td>PHP 版本：</td>
	                                <td><?php echo $sys_info['phpv']; ?></td>
	                                <td>Mysql 版本：</td>
	                                <td><?php echo $sys_info['mysql_version']; ?></td> 
	                                <td>GD 版本</td> 
	                                <td><?php echo $sys_info['gdinfo']; ?></td>  
	                            </tr>   
	                            <tr>
	                                <td>文件上传限制：</td>
	                                <td><?php echo $sys_info['fileupload']; ?></td>
	                                <td>最大占用内存：</td>
	                                <td><?php echo $sys_info['memory_limit']; ?></td> 
	                                <td>最大执行时间：</td> 
	                                <td><?php echo $sys_info['max_ex_time']; ?></td>  
	                            </tr>  
	                            <tr>
	                                <td>安全模式：</td>
	                                <td><?php echo $sys_info['safe_mode']; ?></td>
	                                <td>Zlib支持：</td>
	                                <td><?php echo $sys_info['zlib']; ?></td> 
	                                <td>Curl支持：</td> 
	                                <td><?php echo $sys_info['curl']; ?></td>  
	                            </tr>
	                        </tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</body>
	
	<script type="text/javascript">
		layui.config({
			base: '__PUBLIC__/admin/js/modules/' //你存放新模块的目录，注意，不是layui的模块目录
		}).use('main'); //加载入口
	</script>
</html>